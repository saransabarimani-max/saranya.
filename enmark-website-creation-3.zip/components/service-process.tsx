import { MessageSquare, FileSearch, Hammer, CheckCircle2 } from "lucide-react"

const steps = [
  {
    icon: MessageSquare,
    step: "01",
    title: "Consultation",
    description:
      "We begin by understanding your requirements, challenges, and objectives through detailed discussions.",
  },
  {
    icon: FileSearch,
    step: "02",
    title: "Assessment & Design",
    description: "Our engineers conduct site surveys and develop customized solutions tailored to your needs.",
  },
  {
    icon: Hammer,
    step: "03",
    title: "Execution",
    description: "Professional implementation with strict adherence to safety standards and project timelines.",
  },
  {
    icon: CheckCircle2,
    step: "04",
    title: "Delivery & Support",
    description: "Thorough testing, documentation handover, and ongoing support for peace of mind.",
  },
]

export function ServiceProcess() {
  return (
    <section className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Process</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A systematic approach that ensures quality delivery and customer satisfaction at every step.
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-1/2 w-full h-0.5 bg-border" />
              )}
              <div className="relative flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-background rounded-2xl border-2 border-secondary flex items-center justify-center mb-6 relative z-10">
                  <step.icon className="w-10 h-10 text-secondary" />
                  <span className="absolute -top-3 -right-3 w-8 h-8 bg-secondary text-secondary-foreground rounded-full flex items-center justify-center text-sm font-bold">
                    {step.step}
                  </span>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-muted-foreground text-sm">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
