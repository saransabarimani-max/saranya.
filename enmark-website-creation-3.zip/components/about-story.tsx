import { Building, MapPin, Users, Award } from "lucide-react"

const companyDetails = [
  {
    icon: Building,
    label: "Company Type",
    value: "Private Limited Company",
  },
  {
    icon: MapPin,
    label: "Registered Office",
    value: "Korattur, Chennai, Tamil Nadu",
  },
  {
    icon: Users,
    label: "Team Size",
    value: "15+ Professionals",
  },
  {
    icon: Award,
    label: "Certification",
    value: "ISO 9001:2015",
  },
]

export function AboutStory() {
  return (
    <section className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Story</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground tracking-tight mb-6">
              Building India's Power Infrastructure
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Enmark Power Private Limited was incorporated on{" "}
                <strong className="text-foreground">August 9, 2023</strong>, with a vision to transform the electrical
                infrastructure landscape in India. Registered with the Registrar of Companies, Chennai, our company
                operates under CIN <strong className="text-foreground">U26109TN2023PTC162673</strong>.
              </p>
              <p>
                Founded by experienced professionals from the electrical industry, Enmark Power was established to
                address the growing demand for reliable, efficient, and innovative power solutions across industrial and
                commercial sectors.
              </p>
              <p>
                With an <strong className="text-foreground">authorized capital of Rs. 50 Lakhs</strong> and a{" "}
                <strong className="text-foreground">paid-up capital of Rs. 50 Lakhs</strong>, we have invested in
                state-of-the-art manufacturing capabilities and a skilled workforce to deliver products that meet
                international quality standards.
              </p>
              <p>
                Our registered office is located at{" "}
                <strong className="text-foreground">
                  No 4, Dr. Ambedkar Street, Korattur, Ambattur, Chennai - 600080
                </strong>
                , strategically positioned in Tamil Nadu's industrial hub to serve clients across South India and
                beyond.
              </p>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {companyDetails.map((detail, index) => (
              <div key={index} className="bg-muted p-6 rounded-2xl">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center mb-4">
                  <detail.icon className="w-6 h-6 text-secondary" />
                </div>
                <div className="text-sm text-muted-foreground mb-1">{detail.label}</div>
                <div className="font-semibold text-foreground">{detail.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
