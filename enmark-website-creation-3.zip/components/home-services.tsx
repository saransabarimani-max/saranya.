import Link from "next/link"
import { ArrowRight, Lightbulb, Wrench, Settings, HeadphonesIcon } from "lucide-react"
import { Button } from "@/components/ui/button"

const services = [
  {
    icon: Lightbulb,
    title: "Electrical Design",
    description: "Custom electrical system design tailored to your facility's unique requirements.",
  },
  {
    icon: Wrench,
    title: "Installation",
    description: "Professional installation of all electrical equipment with safety compliance.",
  },
  {
    icon: Settings,
    title: "Maintenance",
    description: "Scheduled maintenance programs to prevent failures and extend asset life.",
  },
  {
    icon: HeadphonesIcon,
    title: "24/7 Support",
    description: "Round-the-clock emergency response and technical assistance.",
  },
]

export function HomeServices() {
  return (
    <section className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Services</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight mb-4">
            Comprehensive Electrical Solutions
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From design to maintenance, we provide end-to-end electrical services for industrial and commercial clients.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {services.map((service, index) => (
            <div key={index} className="group text-center">
              <div className="w-16 h-16 bg-secondary/10 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-secondary/20 transition-colors">
                <service.icon className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{service.title}</h3>
              <p className="text-sm text-muted-foreground">{service.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground" asChild>
            <Link href="/services">
              Explore All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
