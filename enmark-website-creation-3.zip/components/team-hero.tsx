import { Users, Award, Briefcase, GraduationCap } from "lucide-react"

const stats = [
  { icon: Users, value: "25+", label: "Team Members" },
  { icon: Award, value: "50+", label: "Years Combined Experience" },
  { icon: Briefcase, value: "15+", label: "Industry Experts" },
  { icon: GraduationCap, value: "100%", label: "Skilled Workforce" },
]

export function TeamHero() {
  return (
    <section className="pt-32 pb-20 bg-primary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-96 h-96 border border-primary-foreground rounded-full" />
        <div className="absolute bottom-20 right-20 w-64 h-64 border border-primary-foreground rounded-full" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full mb-6">
            <Users className="w-4 h-4 text-secondary" />
            <span className="text-secondary text-sm font-medium">Our People</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 text-balance">
            Meet the Minds Behind
            <span className="text-secondary block mt-2">Enmark Power</span>
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 leading-relaxed">
            Our strength lies in our people. With a dedicated team of engineers, technicians, and industry experts, we
            deliver innovative power solutions that transform industries across India.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-primary-foreground/5 backdrop-blur-sm border border-primary-foreground/10 rounded-2xl p-6 text-center"
            >
              <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-6 h-6 text-secondary" />
              </div>
              <p className="text-3xl md:text-4xl font-bold text-primary-foreground mb-1">{stat.value}</p>
              <p className="text-primary-foreground/70 text-sm">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
