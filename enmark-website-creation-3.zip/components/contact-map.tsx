import { MapPin, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ContactMap() {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="relative h-80">
        <img
          src="/map-location-chennai-ambattur-tamil-nadu.jpg"
          alt="Enmark Power Office Location"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="flex items-start gap-3 mb-4">
            <MapPin className="w-5 h-5 text-secondary shrink-0 mt-1" />
            <div>
              <h4 className="text-primary-foreground font-semibold mb-1">Our Office</h4>
              <p className="text-primary-foreground/90 text-sm">
                No 4, Dr. Ambedkar Street, Korattur, Ambattur, Chennai - 600080, Tamil Nadu, India
              </p>
            </div>
          </div>
          <Button asChild className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground">
            <a
              href="https://maps.google.com/?q=Korattur,Ambattur,Chennai,Tamil+Nadu+600080"
              target="_blank"
              rel="noopener noreferrer"
            >
              Open in Google Maps
              <ExternalLink className="ml-2 w-4 h-4" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
