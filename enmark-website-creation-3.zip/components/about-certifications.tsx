import { Shield, CheckCircle, Award, FileCheck } from "lucide-react"

const certifications = [
  {
    icon: Shield,
    title: "ISO 9001:2015",
    description: "Quality Management System certification ensuring consistent quality in all processes",
  },
  {
    icon: CheckCircle,
    title: "IS/IEC Standards",
    description: "All products comply with Indian Standards and International Electrotechnical Commission norms",
  },
  {
    icon: Award,
    title: "BIS Certified",
    description: "Bureau of Indian Standards certification for electrical equipment safety and performance",
  },
  {
    icon: FileCheck,
    title: "MCA Compliant",
    description: "Fully registered and compliant with Ministry of Corporate Affairs regulations",
  },
]

export function AboutCertifications() {
  return (
    <section className="py-20 lg:py-32 bg-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Trust & Compliance</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-primary-foreground mb-6 text-balance">
            Certifications & Standards
          </h2>
          <p className="text-lg text-primary-foreground/80">
            We adhere to the highest industry standards and maintain certifications that demonstrate our commitment to
            quality and safety.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {certifications.map((cert, index) => (
            <div
              key={index}
              className="bg-primary-foreground/5 border border-primary-foreground/10 rounded-2xl p-8 text-center hover:bg-primary-foreground/10 transition-colors"
            >
              <div className="w-16 h-16 bg-secondary/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <cert.icon className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="text-lg font-bold text-primary-foreground mb-3">{cert.title}</h3>
              <p className="text-primary-foreground/70 text-sm leading-relaxed">{cert.description}</p>
            </div>
          ))}
        </div>

        {/* Company Registration Info */}
        <div className="mt-16 bg-primary-foreground/5 border border-primary-foreground/10 rounded-2xl p-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-primary-foreground/60 text-sm mb-1">Company Identification Number</p>
              <p className="text-primary-foreground font-mono text-sm">U26109TN2023PTC162673</p>
            </div>
            <div>
              <p className="text-primary-foreground/60 text-sm mb-1">Registrar of Companies</p>
              <p className="text-primary-foreground font-semibold">ROC Chennai</p>
            </div>
            <div>
              <p className="text-primary-foreground/60 text-sm mb-1">Authorized Capital</p>
              <p className="text-primary-foreground font-semibold">INR 50,00,000</p>
            </div>
            <div>
              <p className="text-primary-foreground/60 text-sm mb-1">Company Status</p>
              <p className="text-secondary font-semibold">Active</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
