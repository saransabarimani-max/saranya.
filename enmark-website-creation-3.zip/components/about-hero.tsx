import { Building2, Calendar, MapPin, FileCheck } from "lucide-react"

const companyInfo = [
  { icon: Building2, label: "Company Type", value: "Private Limited" },
  { icon: Calendar, label: "Incorporated", value: "9th August 2023" },
  { icon: MapPin, label: "Headquarters", value: "Chennai, Tamil Nadu" },
  { icon: FileCheck, label: "CIN", value: "U26109TN2023PTC162673" },
]

export function AboutHero() {
  return (
    <section className="pt-32 pb-20 bg-primary relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] border border-primary-foreground rounded-full translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] border border-primary-foreground rounded-full -translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full mb-6">
              <Building2 className="w-4 h-4 text-secondary" />
              <span className="text-secondary text-sm font-medium">About Enmark Power</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 text-balance">
              Powering India&apos;s
              <span className="text-secondary block mt-2">Industrial Future</span>
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/80 mb-8 leading-relaxed">
              Enmark Power Private Limited is a dynamic electrical equipment manufacturing company headquartered in
              Chennai, Tamil Nadu. Founded in 2023, we have rapidly established ourselves as a trusted partner for
              industries seeking reliable, high-performance power solutions.
            </p>
            <p className="text-primary-foreground/70 leading-relaxed">
              With a focus on innovation, quality, and customer satisfaction, we design, manufacture, and install
              cutting-edge electrical systems that power businesses across India. Our commitment to excellence and
              sustainable practices sets us apart in the industry.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {companyInfo.map((item, index) => (
              <div
                key={index}
                className="bg-primary-foreground/5 backdrop-blur-sm border border-primary-foreground/10 rounded-2xl p-6"
              >
                <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center mb-4">
                  <item.icon className="w-6 h-6 text-secondary" />
                </div>
                <p className="text-primary-foreground/60 text-sm mb-1">{item.label}</p>
                <p className="text-primary-foreground font-semibold">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
