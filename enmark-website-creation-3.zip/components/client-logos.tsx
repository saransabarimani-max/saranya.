import { Building2 } from "lucide-react"

const industries = [
  "Manufacturing",
  "Automotive",
  "Textiles",
  "Logistics",
  "Healthcare",
  "Retail",
  "IT Parks",
  "Real Estate",
]

export function ClientLogos() {
  return (
    <section className="py-16 bg-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-4">Industries We Serve</h2>
          <p className="text-primary-foreground/70">Trusted by leading businesses across Tamil Nadu and beyond</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {industries.map((industry, index) => (
            <div
              key={index}
              className="flex items-center justify-center gap-3 px-6 py-4 bg-primary-foreground/5 rounded-lg border border-primary-foreground/10 hover:bg-primary-foreground/10 transition-colors"
            >
              <Building2 className="w-5 h-5 text-secondary" />
              <span className="text-primary-foreground font-medium">{industry}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
