import { Star, Quote } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const testimonials = [
  {
    name: "Raghavan Pillai",
    designation: "Plant Manager",
    company: "Chennai Steel Industries",
    image: "/indian-businessman-manager-professional-testimonial.jpg",
    rating: 5,
    text: "Enmark Power transformed our facility's electrical infrastructure. Their transformers have been running flawlessly for over 18 months with zero downtime. The installation team was professional and completed the project ahead of schedule.",
  },
  {
    name: "Anitha Ramesh",
    designation: "Director of Operations",
    company: "Textile Manufacturing Co.",
    image: "/indian-businesswoman-director-professional-testimon.jpg",
    rating: 5,
    text: "We've been partnering with Enmark Power for all our electrical requirements. Their custom switchgear solutions have significantly improved our production efficiency. The after-sales support is exceptional.",
  },
  {
    name: "Subramaniam K",
    designation: "Facility Head",
    company: "Automotive Parts Ltd",
    image: "/indian-engineer-facility-manager-professional-test.jpg",
    rating: 5,
    text: "Outstanding quality and reliability! The distribution panels we purchased have exceeded our expectations. What impressed us most was their technical team's expertise in understanding our specific requirements and delivering perfect solutions.",
  },
]

export function Testimonials() {
  return (
    <section className="py-20 lg:py-32 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Client Testimonials</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight text-balance">
            Trusted by Industry Leaders Across India
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Don't just take our word for it. Here's what our clients have to say about their experience with Enmark
            Power.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-border hover:border-secondary/50 transition-colors">
              <CardContent className="p-6">
                <Quote className="w-10 h-10 text-secondary/20 mb-4" />
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-secondary text-secondary" />
                  ))}
                </div>
                <p className="text-muted-foreground leading-relaxed mb-6">{testimonial.text}</p>
                <div className="flex items-center gap-4">
                  <img
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    className="w-14 h-14 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-semibold text-card-foreground">{testimonial.name}</h4>
                    <p className="text-sm text-muted-foreground">{testimonial.designation}</p>
                    <p className="text-xs text-secondary">{testimonial.company}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
