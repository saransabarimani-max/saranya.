import { Building2, FileCheck, Users, Wrench, Award, Target, Rocket, TrendingUp } from "lucide-react"

const milestones = [
  {
    date: "August 9, 2023",
    title: "Company Incorporation",
    description:
      "Enmark Power Private Limited was officially incorporated and registered with the Registrar of Companies, Chennai. CIN: U26109TN2023PTC162673",
    icon: Building2,
    highlight: true,
  },
  {
    date: "September 2023",
    title: "Infrastructure Setup",
    description:
      "Established our headquarters at Banu Nagar, Ambattur, Tamil Nadu. Set up initial manufacturing capabilities and procurement networks.",
    icon: Wrench,
  },
  {
    date: "October 2023",
    title: "Team Formation",
    description:
      "Assembled a team of experienced engineers and power system specialists with combined experience of over 50 years in the industry.",
    icon: Users,
  },
  {
    date: "November 2023",
    title: "Quality Certifications",
    description:
      "Initiated the process for obtaining ISO certifications and industry compliance standards for our manufacturing processes.",
    icon: FileCheck,
  },
  {
    date: "Q1 2024",
    title: "First Product Line Launch",
    description:
      "Successfully launched our initial product portfolio including power transformers, distribution panels, and industrial switchgear solutions.",
    icon: Rocket,
  },
  {
    date: "March 2024",
    title: "FY 2023-24 Completion",
    description:
      "Completed our first financial year with strong foundational growth, establishing key partnerships and customer relationships.",
    icon: TrendingUp,
  },
  {
    date: "Q2 2024",
    title: "Market Expansion",
    description:
      "Expanded our service coverage across Tamil Nadu and initiated partnerships with industrial clients in neighboring states.",
    icon: Target,
  },
  {
    date: "December 31, 2024",
    title: "Annual General Meeting",
    description:
      "Successfully conducted our AGM, reviewing annual performance and setting strategic goals for 2025 with focus on expansion and innovation.",
    icon: Award,
    highlight: true,
  },
]

export function MilestoneTimeline() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-secondary font-semibold text-sm tracking-wider uppercase">Our Timeline</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-4 text-balance">
            Key Milestones & Achievements
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            Every step of our journey has been marked by dedication, innovation, and a relentless pursuit of excellence
            in the power solutions industry.
          </p>
        </div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-border md:-translate-x-0.5" />

          <div className="space-y-12">
            {milestones.map((milestone, index) => (
              <div
                key={index}
                className={`relative flex flex-col md:flex-row gap-8 ${index % 2 === 0 ? "md:flex-row-reverse" : ""}`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-4 md:left-1/2 w-4 h-4 bg-secondary rounded-full border-4 border-background md:-translate-x-1/2 z-10 top-6" />

                {/* Content */}
                <div className={`md:w-1/2 pl-12 md:pl-0 ${index % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}>
                  <div
                    className={`p-6 rounded-xl ${milestone.highlight ? "bg-primary text-primary-foreground" : "bg-card border border-border"}`}
                  >
                    <div
                      className={`inline-flex items-center gap-2 text-sm font-medium mb-3 ${milestone.highlight ? "text-secondary" : "text-secondary"}`}
                    >
                      <milestone.icon className="w-4 h-4" />
                      {milestone.date}
                    </div>
                    <h3
                      className={`text-xl font-bold mb-2 ${milestone.highlight ? "text-primary-foreground" : "text-foreground"}`}
                    >
                      {milestone.title}
                    </h3>
                    <p className={milestone.highlight ? "text-primary-foreground/80" : "text-muted-foreground"}>
                      {milestone.description}
                    </p>
                  </div>
                </div>

                {/* Spacer for alternating layout */}
                <div className="hidden md:block md:w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
