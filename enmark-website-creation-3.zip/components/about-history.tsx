import { Factory, Users, Award, TrendingUp } from "lucide-react"

export function AboutHistory() {
  return (
    <section className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Story</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6 text-balance">
              From Vision to Reality: The Enmark Journey
            </h2>
            <div className="space-y-6 text-muted-foreground leading-relaxed">
              <p>
                Enmark Power Private Limited was founded on <strong className="text-foreground">August 9, 2023</strong>,
                in the industrial hub of Ambattur, Chennai. The company was born from a vision to bridge the gap between
                quality and accessibility in India&apos;s power equipment sector.
              </p>
              <p>
                Registered under the Ministry of Corporate Affairs with CIN{" "}
                <strong className="text-foreground">U26109TN2023PTC162673</strong>, Enmark Power started with an
                authorized capital of <strong className="text-foreground">INR 50,00,000</strong> and a fully paid-up
                capital of the same amount, demonstrating strong financial commitment from day one.
              </p>
              <p>
                Within just two years of operation, we have successfully completed our first Annual General Meeting on
                December 31, 2024, marking a significant corporate milestone. Our rapid growth is a testament to our
                team&apos;s dedication and our clients&apos; trust in our capabilities.
              </p>
              <p>
                Today, we serve diverse industries including manufacturing, healthcare, retail, and logistics, providing
                end-to-end power solutions that meet the highest standards of quality and reliability.
              </p>
            </div>
          </div>

          <div className="relative">
            <img
              src="/modern-electrical-manufacturing-facility-india-wor.jpg"
              alt="Enmark Power Manufacturing Facility"
              className="w-full h-[500px] object-cover rounded-2xl"
            />
            <div className="absolute -bottom-8 -left-8 bg-card border border-border p-6 rounded-2xl shadow-xl hidden lg:block">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-secondary/10 rounded-xl flex items-center justify-center">
                  <Factory className="w-8 h-8 text-secondary" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-foreground">2+</p>
                  <p className="text-muted-foreground text-sm">Years of Excellence</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Key Highlights */}
        <div className="mt-20 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-muted rounded-2xl p-6 text-center">
            <Factory className="w-10 h-10 text-secondary mx-auto mb-4" />
            <h4 className="font-semibold text-foreground mb-2">Manufacturing Excellence</h4>
            <p className="text-muted-foreground text-sm">State-of-the-art facility in Chennai with modern equipment</p>
          </div>
          <div className="bg-muted rounded-2xl p-6 text-center">
            <Users className="w-10 h-10 text-secondary mx-auto mb-4" />
            <h4 className="font-semibold text-foreground mb-2">Expert Team</h4>
            <p className="text-muted-foreground text-sm">25+ skilled professionals with industry expertise</p>
          </div>
          <div className="bg-muted rounded-2xl p-6 text-center">
            <Award className="w-10 h-10 text-secondary mx-auto mb-4" />
            <h4 className="font-semibold text-foreground mb-2">Quality Standards</h4>
            <p className="text-muted-foreground text-sm">ISO certified processes and IS/IEC compliance</p>
          </div>
          <div className="bg-muted rounded-2xl p-6 text-center">
            <TrendingUp className="w-10 h-10 text-secondary mx-auto mb-4" />
            <h4 className="font-semibold text-foreground mb-2">Rapid Growth</h4>
            <p className="text-muted-foreground text-sm">Expanding operations across South India</p>
          </div>
        </div>
      </div>
    </section>
  )
}
