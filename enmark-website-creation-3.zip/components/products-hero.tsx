import { Zap, Shield, Award } from "lucide-react"

export function ProductsHero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 bg-primary text-primary-foreground overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-secondary rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Products</p>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            Premium Electrical
            <span className="text-secondary block">Equipment & Solutions</span>
          </h1>
          <p className="text-xl text-primary-foreground/80 mb-8 leading-relaxed">
            Discover our comprehensive range of high-quality electrical products designed for industrial and commercial
            applications. Each product is manufactured to meet international standards and backed by our commitment to
            excellence.
          </p>

          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <div className="font-semibold">High Efficiency</div>
                <div className="text-sm text-primary-foreground/60">98%+ Efficiency Rating</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <div className="font-semibold">Safety Certified</div>
                <div className="text-sm text-primary-foreground/60">IS/IEC Compliant</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <div className="font-semibold">Warranty</div>
                <div className="text-sm text-primary-foreground/60">2 Year Coverage</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
