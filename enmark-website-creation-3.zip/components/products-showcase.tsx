import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const products = [
  {
    id: 1,
    name: "Power Transformer - 100 KVA",
    category: "Transformers",
    voltage: "11kV/433V",
    description:
      "Three-phase oil-immersed power transformer with ONAN cooling, designed for industrial distribution networks. Features copper windings and CRGO core for maximum efficiency.",
    features: ["ONAN Cooling", "Copper Windings", "CRGO Core", "IP54 Rated"],
    image: "/industrial-power-transformer-100-kva-electrical-eq.jpg",
    price: "On Request",
    popular: true,
  },
  {
    id: 2,
    name: "Power Transformer - 250 KVA",
    category: "Transformers",
    voltage: "11kV/433V",
    description:
      "Heavy-duty transformer suitable for medium-scale industrial facilities. Built with advanced insulation and designed for continuous operation under varying load conditions.",
    features: ["ONAN/ONAF Cooling", "Tap Changer", "Oil Level Indicator", "Thermometer Pocket"],
    image: "/industrial-power-transformer-250-kva-heavy-duty.jpg",
    price: "On Request",
    popular: false,
  },
  {
    id: 3,
    name: "Power Transformer - 500 KVA",
    category: "Transformers",
    voltage: "33kV/433V",
    description:
      "High-capacity transformer for large industrial plants and commercial complexes. Features enhanced protection systems and remote monitoring capabilities.",
    features: ["Buchholz Relay", "PRV Protection", "Remote Monitoring", "Silica Gel Breather"],
    image: "/industrial-power-transformer-500-kva-large-capacit.jpg",
    price: "On Request",
    popular: false,
  },
  {
    id: 4,
    name: "Power Transformer - 1000 KVA",
    category: "Transformers",
    voltage: "33kV/433V",
    description:
      "Premium transformer for heavy industrial applications with advanced cooling and protection systems. Suitable for 24/7 operation in demanding environments.",
    features: ["ONAF Cooling", "Winding Temperature Indicator", "Marshalling Box", "Conservator Tank"],
    image: "/industrial-power-transformer-1000-kva-premium-heav.jpg",
    price: "On Request",
    popular: true,
  },
  {
    id: 5,
    name: "Main Distribution Panel - LT",
    category: "Panels",
    voltage: "415V",
    description:
      "Low tension main distribution panel with ACB incoming and MCCB outgoing feeders. Designed for efficient power distribution in commercial and industrial buildings.",
    features: ["ACB Protection", "MCCB Feeders", "Digital Metering", "Form 4 Construction"],
    image: "/electrical-distribution-panel-lt-main-switchboard.jpg",
    price: "On Request",
    popular: false,
  },
  {
    id: 6,
    name: "Power Control Centre (PCC)",
    category: "Panels",
    voltage: "415V",
    description:
      "Centralized power control centre for motor control and power distribution. Features intelligent protection relays and energy management systems.",
    features: ["Motor Starters", "VFD Compatible", "Touch Screen HMI", "Communication Gateway"],
    image: "/power-control-centre-pcc-electrical-panel-industri.jpg",
    price: "On Request",
    popular: true,
  },
  {
    id: 7,
    name: "Motor Control Centre (MCC)",
    category: "Panels",
    voltage: "415V",
    description:
      "Modular motor control centre with draw-out type construction for easy maintenance. Includes intelligent motor protection relays and local/remote control options.",
    features: ["Draw-out Design", "IMPR Protection", "LED Indication", "Metering per Feeder"],
    image: "/motor-control-centre-mcc-electrical-panel-modular.jpg",
    price: "On Request",
    popular: false,
  },
  {
    id: 8,
    name: "VCB Panel - 11kV",
    category: "Switchgear",
    voltage: "11kV",
    description:
      "Vacuum circuit breaker panel for medium voltage switching applications. Features arc-less interruption and minimal maintenance requirements.",
    features: ["25kA Breaking Capacity", "Motorized Operation", "Protection Relays", "Interlocking"],
    image: "/vcb-panel-11kv-vacuum-circuit-breaker-switchgear.jpg",
    price: "On Request",
    popular: true,
  },
  {
    id: 9,
    name: "Ring Main Unit (RMU)",
    category: "Switchgear",
    voltage: "11kV",
    description:
      "Compact SF6 insulated ring main unit for secondary distribution networks. Ideal for commercial buildings, hospitals, and industrial estates.",
    features: ["SF6 Insulated", "Compact Design", "Load Break Switch", "Fault Indicators"],
    image: "/ring-main-unit-rmu-11kv-compact-switchgear.jpg",
    price: "On Request",
    popular: false,
  },
  {
    id: 10,
    name: "HT Metering Cubicle",
    category: "Switchgear",
    voltage: "11kV/33kV",
    description:
      "High tension metering cubicle with CT/PT units for accurate energy measurement. Designed as per TNEB/TANGEDCO specifications.",
    features: ["CT/PT Metering", "TNEB Approved", "Tamper Proof", "Outdoor Installation"],
    image: "/ht-metering-cubicle-high-tension-electrical-panel.jpg",
    price: "On Request",
    popular: false,
  },
  {
    id: 11,
    name: "SCADA Control System",
    category: "Control",
    voltage: "24V DC",
    description:
      "Comprehensive SCADA system for remote monitoring and control of electrical infrastructure. Includes real-time data acquisition and alarm management.",
    features: ["Real-time Monitoring", "Historical Trending", "Alarm Management", "Mobile Access"],
    image: "/scada-control-system-industrial-automation-monitor.jpg",
    price: "On Request",
    popular: true,
  },
  {
    id: 12,
    name: "PLC-based Automation Panel",
    category: "Control",
    voltage: "24V DC",
    description:
      "Programmable logic controller based automation panel for process control and sequence operations. Compatible with various industrial protocols.",
    features: ["Siemens/AB PLC", "HMI Interface", "Modbus/Profibus", "Remote I/O"],
    image: "/placeholder.svg?height=400&width=500",
    price: "On Request",
    popular: false,
  },
]

export function ProductsShowcase() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Complete Product Range</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            From transformers to control systems, we offer a complete range of electrical equipment for every
            application.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card
              key={product.id}
              className="group overflow-hidden border-border hover:border-secondary/50 transition-all duration-300 hover:shadow-lg"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {product.popular && (
                  <Badge className="absolute top-4 left-4 bg-secondary text-secondary-foreground">Popular</Badge>
                )}
                <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm px-3 py-1 rounded-full">
                  <span className="text-sm font-medium text-foreground">{product.voltage}</span>
                </div>
              </div>
              <CardContent className="p-6">
                <Badge variant="outline" className="mb-3 text-secondary border-secondary">
                  {product.category}
                </Badge>
                <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-secondary transition-colors">
                  {product.name}
                </h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{product.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {product.features.slice(0, 3).map((feature, idx) => (
                    <span key={idx} className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded">
                      {feature}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-secondary font-semibold">{product.price}</span>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground bg-transparent"
                  >
                    Get Quote
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
