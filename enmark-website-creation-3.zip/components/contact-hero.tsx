import { Mail, Phone, MapPin } from "lucide-react"

export function ContactHero() {
  return (
    <section className="relative pt-32 pb-20 bg-primary overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="/industrial-control-room-electrical-systems-techni.jpg"
          alt="Contact Enmark Power"
          className="w-full h-full object-cover opacity-20"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 tracking-tight">
            Get In Touch With Us
          </h1>
          <p className="text-xl text-primary-foreground/80 leading-relaxed mb-12">
            Have a question or need a quote? Our team of experts is ready to assist you with any electrical power
            requirements.
          </p>

          <div className="grid sm:grid-cols-3 gap-6">
            <div className="bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 rounded-xl p-6">
              <Phone className="w-8 h-8 text-secondary mx-auto mb-3" />
              <p className="text-primary-foreground/60 text-sm mb-1">Call Us</p>
              <p className="text-primary-foreground font-semibold">+91 44 2625 1234</p>
            </div>
            <div className="bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 rounded-xl p-6">
              <Mail className="w-8 h-8 text-secondary mx-auto mb-3" />
              <p className="text-primary-foreground/60 text-sm mb-1">Email Us</p>
              <p className="text-primary-foreground font-semibold">info@enmarkpower.com</p>
            </div>
            <div className="bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 rounded-xl p-6">
              <MapPin className="w-8 h-8 text-secondary mx-auto mb-3" />
              <p className="text-primary-foreground/60 text-sm mb-1">Visit Us</p>
              <p className="text-primary-foreground font-semibold">Chennai, Tamil Nadu</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
