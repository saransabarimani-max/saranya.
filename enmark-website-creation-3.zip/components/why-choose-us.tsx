import { Shield, Clock, Award, Users, Wrench, Headphones } from "lucide-react"

const reasons = [
  {
    icon: Shield,
    title: "Quality Assured",
    description:
      "All products undergo rigorous testing and comply with IS/IEC standards for maximum reliability and safety.",
  },
  {
    icon: Clock,
    title: "Timely Delivery",
    description:
      "We understand the importance of schedules and ensure on-time delivery of equipment and project completion.",
  },
  {
    icon: Award,
    title: "Certified Excellence",
    description: "ISO 9001:2015 certified company with adherence to the highest quality management standards.",
  },
  {
    icon: Users,
    title: "Expert Team",
    description: "Our team of qualified engineers and technicians brings decades of combined industry experience.",
  },
  {
    icon: Wrench,
    title: "Custom Solutions",
    description:
      "We design and manufacture equipment tailored to your specific operational requirements and constraints.",
  },
  {
    icon: Headphones,
    title: "After-Sales Support",
    description:
      "Comprehensive warranty coverage and responsive after-sales service to keep your systems running smoothly.",
  },
]

export function WhyChooseUs() {
  return (
    <section className="py-20 lg:py-32 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Why Choose Us</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">The Enmark Power Advantage</h2>
          <p className="text-primary-foreground/70 max-w-2xl mx-auto">
            We combine technical expertise with customer-centric service to deliver exceptional value.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div key={index} className="group">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 bg-primary-foreground/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-secondary transition-colors">
                  <reason.icon className="w-7 h-7 text-primary-foreground group-hover:text-secondary-foreground transition-colors" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">{reason.title}</h3>
                  <p className="text-primary-foreground/70 text-sm leading-relaxed">{reason.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
