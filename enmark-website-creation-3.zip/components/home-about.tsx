import Link from "next/link"
import { ArrowRight, CheckCircle, Award, Users, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"

const highlights = [
  "ISO 9001:2015 Certified Company",
  "50+ Lakhs Authorized Capital",
  "ROC Chennai Registered",
  "Pan-India Service Network",
]

export function HomeAbout() {
  return (
    <section className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image Section */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden">
              <img
                src="/modern-industrial-electrical-manufacturing-facilit.jpg"
                alt="Enmark Power Facility"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent" />
            </div>
            {/* Floating Stats Card */}
            <div className="absolute -bottom-8 -right-8 bg-secondary text-secondary-foreground p-6 rounded-2xl shadow-xl">
              <div className="text-4xl font-bold">2023</div>
              <div className="text-sm opacity-90">Year Established</div>
            </div>
            {/* Floating Badge */}
            <div className="absolute top-6 left-6 bg-card/95 backdrop-blur-sm p-4 rounded-xl shadow-lg">
              <div className="flex items-center gap-3">
                <Award className="w-8 h-8 text-secondary" />
                <div>
                  <div className="font-semibold text-foreground">Certified</div>
                  <div className="text-xs text-muted-foreground">Quality Assured</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div>
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">About Enmark Power</p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight mb-6">
              Powering India's
              <span className="text-secondary block">Industrial Growth</span>
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Enmark Power Private Limited is a Chennai-based electrical solutions company incorporated on August 9,
              2023. Registered with the Registrar of Companies, Chennai under CIN U26109TN2023PTC162673, we specialize
              in manufacturing and supplying high-quality power equipment.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              With an authorized capital of Rs. 50 Lakhs, we have rapidly established ourselves as a trusted partner for
              industries seeking reliable electrical infrastructure solutions. Our headquarters in Korattur, Chennai
              serves as the hub for our growing operations across Tamil Nadu and beyond.
            </p>

            {/* Highlights */}
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {highlights.map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0" />
                  <span className="text-foreground font-medium">{item}</span>
                </div>
              ))}
            </div>

            {/* Quick Stats */}
            <div className="flex flex-wrap gap-8 mb-8 pb-8 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-foreground">25+</div>
                  <div className="text-sm text-muted-foreground">Projects Delivered</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-foreground">15+</div>
                  <div className="text-sm text-muted-foreground">Expert Engineers</div>
                </div>
              </div>
            </div>

            <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground" asChild>
              <Link href="/about">
                Learn More About Us
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
