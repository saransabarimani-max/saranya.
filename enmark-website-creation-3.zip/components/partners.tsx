const partners = [
  "Tata Power",
  "L&T Electrical",
  "Siemens India",
  "ABB India",
  "Schneider Electric",
  "Havells",
  "Crompton Greaves",
  "BHEL",
]

export function Partners() {
  return (
    <section className="py-16 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <p className="text-muted-foreground font-medium">Trusted by Leading Companies</p>
        </div>
        <div className="flex flex-wrap justify-center items-center gap-8 lg:gap-16">
          {partners.map((partner, index) => (
            <div
              key={index}
              className="text-muted-foreground/50 font-bold text-lg hover:text-secondary transition-colors"
            >
              {partner}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
