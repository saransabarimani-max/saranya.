import Link from "next/link"
import { Zap, Linkedin, Twitter, Facebook, Mail, Instagram, Youtube, Phone, MapPin, MessageCircle } from "lucide-react"

const footerLinks = {
  company: [
    { label: "About Us", href: "/about" },
    { label: "Our Team", href: "/team" },
    { label: "Milestones", href: "/milestones" },
    { label: "Projects", href: "/projects" },
    { label: "Connect With Us", href: "/connect" },
  ],
  products: [
    { label: "Power Transformers", href: "/products" },
    { label: "Distribution Panels", href: "/products" },
    { label: "Industrial Switchgear", href: "/products" },
    { label: "Control Systems", href: "/products" },
  ],
  services: [
    { label: "Electrical Design", href: "/services" },
    { label: "Installation Services", href: "/services" },
    { label: "Preventive Maintenance", href: "/services" },
    { label: "24/7 Technical Support", href: "/services" },
  ],
  legal: [
    { label: "Privacy Policy", href: "/privacy-policy" },
    { label: "Terms of Service", href: "/terms" },
    { label: "Contact Us", href: "/contact" },
  ],
}

const socialLinks = [
  { icon: Linkedin, href: "https://www.linkedin.com/company/enmark-power-private-limited", label: "LinkedIn" },
  { icon: Twitter, href: "https://twitter.com/enmarkpower", label: "Twitter" },
  { icon: Facebook, href: "https://www.facebook.com/enmarkpower", label: "Facebook" },
  { icon: Instagram, href: "https://www.instagram.com/enmarkpower", label: "Instagram" },
  { icon: Youtube, href: "https://www.youtube.com/@enmarkpower", label: "YouTube" },
  { icon: MessageCircle, href: "https://wa.me/919840112345", label: "WhatsApp" },
]

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-3 lg:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-secondary-foreground" />
              </div>
              <span className="text-xl font-bold tracking-tight">
                ENMARK<span className="text-secondary">POWER</span>
              </span>
            </Link>
            <p className="text-primary-foreground/70 mb-4 max-w-xs">
              Powering industries with innovative electrical solutions and world-class engineering excellence since
              2023.
            </p>

            {/* Contact Info */}
            <div className="space-y-3 mb-6 text-sm">
              <div className="flex items-center gap-2 text-primary-foreground/70">
                <Phone className="w-4 h-4 text-secondary" />
                <div className="flex flex-col">
                  <a href="tel:+914426251234" className="hover:text-secondary transition-colors">
                    +91 44 2625 1234
                  </a>
                  <a href="tel:+919840112345" className="hover:text-secondary transition-colors">
                    +91 98401 12345
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-2 text-primary-foreground/70">
                <Mail className="w-4 h-4 text-secondary" />
                <a href="mailto:info@enmarkpower.com" className="hover:text-secondary transition-colors">
                  info@enmarkpower.com
                </a>
              </div>
              <div className="flex items-start gap-2 text-primary-foreground/70">
                <MapPin className="w-4 h-4 text-secondary shrink-0 mt-0.5" />
                <address className="not-italic">
                  No 4, Dr. Ambedkar Street,
                  <br />
                  Korattur, Chennai - 600080,
                  <br />
                  Tamil Nadu, India
                </address>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="w-10 h-10 bg-primary-foreground/10 rounded-lg flex items-center justify-center hover:bg-secondary hover:text-secondary-foreground transition-colors"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-primary-foreground/70 hover:text-secondary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Products Links */}
          <div>
            <h4 className="font-semibold mb-4">Products</h4>
            <ul className="space-y-3">
              {footerLinks.products.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-primary-foreground/70 hover:text-secondary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services Links */}
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-3">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-primary-foreground/70 hover:text-secondary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link, index) => (
                <li key={index}>
                  <Link
                    href={link.href}
                    className="text-primary-foreground/70 hover:text-secondary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-primary-foreground/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-primary-foreground/60 text-sm">
            © {new Date().getFullYear()} Enmark Power Private Limited. All rights reserved.
          </p>
          <p className="text-primary-foreground/60 text-sm">CIN: U26109TN2023PTC162673 | Made in India</p>
        </div>
      </div>
    </footer>
  )
}
