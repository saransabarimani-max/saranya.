import { ArrowRight, Lightbulb, Globe, Leaf, Cpu } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

const futureGoals = [
  {
    icon: Globe,
    title: "Pan-India Expansion",
    description: "Extend our service network across all major industrial hubs in India by 2026.",
  },
  {
    icon: Leaf,
    title: "Sustainable Solutions",
    description: "Pioneer eco-friendly power solutions with reduced carbon footprint and energy efficiency.",
  },
  {
    icon: Cpu,
    title: "Smart Power Systems",
    description: "Integrate IoT and AI-driven monitoring systems into our product line for predictive maintenance.",
  },
  {
    icon: Lightbulb,
    title: "R&D Excellence",
    description: "Establish dedicated research facility for developing next-generation power technologies.",
  },
]

export function FutureVision() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-secondary font-semibold text-sm tracking-wider uppercase">Looking Ahead</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-4 text-balance">
            Our Vision for the Future
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            As we continue to grow, our focus remains on innovation, sustainability, and delivering unparalleled value
            to our customers and stakeholders.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {futureGoals.map((goal, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-xl p-6 hover:border-secondary transition-colors group"
            >
              <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-secondary transition-colors">
                <goal.icon className="w-6 h-6 text-secondary group-hover:text-secondary-foreground transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{goal.title}</h3>
              <p className="text-muted-foreground text-sm">{goal.description}</p>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-primary rounded-2xl p-8 md:p-12 text-center">
          <h3 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-4 text-balance">
            Be Part of Our Journey
          </h3>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto mb-8 text-pretty">
            Whether you're looking for reliable power solutions or want to partner with us, we'd love to hear from you.
            Let's build a powerful future together.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/#contact">
              <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                Contact Us
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <Link href="/#products">
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 bg-transparent"
              >
                View Products
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
