import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { MapPin, Calendar, Zap, Building, Factory, Warehouse, ShoppingBag, Hospital } from "lucide-react"

const projects = [
  {
    id: 1,
    title: "Ambattur Industrial Estate Power Upgrade",
    category: "Industrial",
    location: "Ambattur, Chennai",
    year: "2024",
    description:
      "Complete electrical infrastructure overhaul for a 50,000 sq.ft manufacturing facility including transformer installation and panel upgrades.",
    capacity: "500 KVA",
    image: "/industrial-power-plant-electrical-infrastructure.jpg",
    icon: Factory,
    status: "Completed",
  },
  {
    id: 2,
    title: "Commercial Complex Distribution System",
    category: "Commercial",
    location: "T. Nagar, Chennai",
    year: "2024",
    description:
      "Designed and installed comprehensive power distribution system for a 12-floor commercial building with backup power integration.",
    capacity: "750 KVA",
    image: "/commercial-building-electrical-distribution-panel.jpg",
    icon: Building,
    status: "Completed",
  },
  {
    id: 3,
    title: "Textile Mill Automation Project",
    category: "Manufacturing",
    location: "Coimbatore",
    year: "2024",
    description:
      "Implemented advanced motor control systems and automated switchgear for seamless production line operations.",
    capacity: "1000 KVA",
    image: "/textile-factory-automation-electrical-systems.jpg",
    icon: Factory,
    status: "Completed",
  },
  {
    id: 4,
    title: "Logistics Hub Power Infrastructure",
    category: "Warehousing",
    location: "Sriperumbudur",
    year: "2024",
    description:
      "End-to-end electrical solution for a modern logistics warehouse including high-efficiency lighting and EV charging stations.",
    capacity: "400 KVA",
    image: "/logistics-warehouse-electrical-infrastructure.jpg",
    icon: Warehouse,
    status: "Completed",
  },
  {
    id: 5,
    title: "Retail Chain Store Electrical Fit-out",
    category: "Retail",
    location: "Multiple Locations",
    year: "2023-2024",
    description:
      "Standardized electrical installations across 8 retail outlets with energy-efficient solutions and smart metering.",
    capacity: "150 KVA each",
    image: "/retail-store-electrical-installation-modern.jpg",
    icon: ShoppingBag,
    status: "Completed",
  },
  {
    id: 6,
    title: "Healthcare Facility Critical Power",
    category: "Healthcare",
    location: "Tambaram, Chennai",
    year: "2024",
    description:
      "Installed critical power systems including UPS, isolation transformers, and emergency backup for a multi-specialty clinic.",
    capacity: "300 KVA",
    image: "/hospital-electrical-critical-power-systems.jpg",
    icon: Hospital,
    status: "In Progress",
  },
]

export function ProjectsGrid() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Featured Projects</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Each project reflects our commitment to quality, safety, and innovation in electrical engineering.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <Card
              key={project.id}
              className="group overflow-hidden border-border hover:border-secondary/50 transition-all duration-300 hover:shadow-lg"
            >
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 flex gap-2">
                  <Badge
                    className={`${project.status === "Completed" ? "bg-green-600" : "bg-secondary"} text-primary-foreground`}
                  >
                    {project.status}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <div className="w-10 h-10 bg-primary/90 rounded-lg flex items-center justify-center">
                    <project.icon className="w-5 h-5 text-primary-foreground" />
                  </div>
                </div>
              </div>

              <CardContent className="p-6">
                <Badge variant="outline" className="mb-3 text-secondary border-secondary">
                  {project.category}
                </Badge>

                <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-secondary transition-colors">
                  {project.title}
                </h3>

                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{project.description}</p>

                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <MapPin className="w-4 h-4 text-secondary" />
                    {project.location}
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Calendar className="w-4 h-4 text-secondary" />
                    {project.year}
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Zap className="w-4 h-4 text-secondary" />
                    {project.capacity}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
