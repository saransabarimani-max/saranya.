import { Award, CheckCircle, Shield, FileCheck } from "lucide-react"

const certifications = [
  {
    icon: Award,
    title: "ISO 9001:2015",
    description: "Quality Management System Certified",
  },
  {
    icon: Shield,
    title: "CE Marking",
    description: "European Conformity Standards",
  },
  {
    icon: CheckCircle,
    title: "BIS Certified",
    description: "Bureau of Indian Standards Approved",
  },
  {
    icon: FileCheck,
    title: "IEC Standards",
    description: "International Electrotechnical Commission Compliant",
  },
]

export function Certifications() {
  return (
    <section className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Quality Assurance</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight text-balance">
            Certified Excellence in Every Product
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Our commitment to quality is backed by internationally recognized certifications and rigorous testing
            procedures that ensure every product meets the highest standards.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {certifications.map((cert, index) => (
            <div
              key={index}
              className="text-center p-8 bg-card border border-border rounded-xl hover:border-secondary/50 hover:shadow-lg transition-all"
            >
              <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <cert.icon className="w-8 h-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">{cert.title}</h3>
              <p className="text-muted-foreground text-sm">{cert.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-primary text-primary-foreground rounded-2xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl sm:text-3xl font-bold mb-4">Our Quality Commitment</h3>
              <p className="text-primary-foreground/80 leading-relaxed mb-6">
                Every Enmark Power product undergoes rigorous testing protocols including high voltage testing,
                temperature rise tests, insulation resistance testing, and load performance validation. We maintain
                strict quality control at every stage of manufacturing to ensure reliability and safety.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0 mt-0.5" />
                  <span className="text-primary-foreground/90">100% factory testing before dispatch</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0 mt-0.5" />
                  <span className="text-primary-foreground/90">
                    Compliance with all Indian and international standards
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0 mt-0.5" />
                  <span className="text-primary-foreground/90">Detailed test reports with every product</span>
                </li>
              </ul>
            </div>
            <div className="relative">
              <img
                src="/quality-testing-electrical-equipment-laboratory.jpg"
                alt="Quality Testing"
                className="w-full h-80 object-cover rounded-xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
