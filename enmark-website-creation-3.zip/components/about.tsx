import { Target, Award, Users, Shield } from "lucide-react"

const values = [
  {
    icon: Target,
    title: "Our Mission",
    description:
      "To deliver innovative power solutions that exceed industry standards while maintaining environmental responsibility.",
  },
  {
    icon: Award,
    title: "Quality First",
    description:
      "Every product undergoes rigorous testing to ensure peak performance and longevity in demanding conditions.",
  },
  {
    icon: Users,
    title: "Client Focus",
    description:
      "We build lasting partnerships by understanding unique requirements and delivering tailored solutions.",
  },
  {
    icon: Shield,
    title: "Reliability",
    description: "Our products are engineered to perform consistently, ensuring your operations run smoothly 24/7.",
  },
]

export function About() {
  return (
    <section id="about" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">About Enmark Power</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight text-balance">
            Engineering Power Solutions for a Sustainable Future
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Founded in 2023, Enmark Power Private Limited has rapidly emerged as a trusted name in the electrical
            equipment manufacturing industry. Based in Tamil Nadu, India, we specialize in designing and manufacturing
            high-quality power solutions.
          </p>
        </div>

        {/* Values Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <div
              key={index}
              className="group p-6 bg-card border border-border rounded-xl hover:border-secondary/50 transition-all duration-300"
            >
              <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-secondary/20 transition-colors">
                <value.icon className="w-6 h-6 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-2">{value.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>

        {/* Featured Image Section */}
        <div className="mt-20 grid lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <img
              src="/modern-electrical-manufacturing-facility-workers-e.jpg"
              alt="Enmark Power manufacturing facility"
              className="w-full h-[400px] object-cover rounded-2xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-secondary text-secondary-foreground p-6 rounded-xl hidden lg:block">
              <p className="text-4xl font-bold">2+</p>
              <p className="text-sm font-medium">Years of Excellence</p>
            </div>
          </div>
          <div>
            <h3 className="text-2xl sm:text-3xl font-bold text-foreground mb-6">
              Combining Innovation with Reliability
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-6">
              At Enmark Power, we understand that reliable power is the backbone of modern industry. Our
              state-of-the-art manufacturing facility in Ambattur, Tamil Nadu, is equipped with the latest technology to
              produce world-class electrical equipment.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Our team of experienced engineers and technicians work tirelessly to ensure every product meets the
              highest standards of quality and safety. We are committed to sustainable practices and continuous
              innovation.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
