import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, Mail, ArrowRight } from "lucide-react"

export function ProductsCta() {
  return (
    <section className="py-20 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Need Custom Specifications?</h2>
        <p className="text-primary-foreground/70 max-w-2xl mx-auto mb-8">
          Our engineering team can design and manufacture equipment tailored to your specific requirements. Contact us
          for a detailed discussion.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
          <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground" asChild>
            <Link href="/contact">
              Request Quote
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-primary-foreground/30 text-primary-foreground bg-transparent hover:bg-primary-foreground/10"
            asChild
          >
            <a href="tel:+914426251234">
              <Phone className="mr-2 w-5 h-5" />
              +91 44 2625 1234
            </a>
          </Button>
        </div>

        <div className="flex items-center justify-center gap-2 text-primary-foreground/60">
          <Mail className="w-4 h-4" />
          <span>sales@enmarkpower.com</span>
        </div>
      </div>
    </section>
  )
}
