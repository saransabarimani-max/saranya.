import { CheckCircle } from "lucide-react"

const specifications = {
  transformers: [
    "Voltage Range: 11kV to 220kV",
    "Capacity: 25 KVA to 5000 KVA",
    "Cooling: ONAN / ONAF / OFAF",
    "Standards: IS 1180 / IS 2026 / IEC 60076",
    "Insulation Class: A / E / B / F / H",
    "Frequency: 50 Hz",
    "Tap Changer: Off-circuit / On-load",
    "Core: CRGO Silicon Steel",
    "Winding: Copper / Aluminium",
    "Tank: MS Fabricated with Radiators",
  ],
  panels: [
    "Voltage: 415V / 690V",
    "Current Rating: Up to 6300A",
    "Short Circuit: Up to 65kA",
    "Form of Separation: Form 1 to Form 4",
    "Degree of Protection: IP42 to IP65",
    "Standards: IEC 61439 / IS 8623",
    "Bus Bar: Copper / Aluminium",
    "Switchgear: ACB / MCCB / MCB",
    "Metering: Digital / Analog",
    "Finish: Powder Coated RAL 7035",
  ],
}

export function ProductSpecs() {
  return (
    <section className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Technical Details</p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Product Specifications</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            All our products are manufactured to international standards with customization options available.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-card p-8 rounded-2xl border border-border">
            <h3 className="text-xl font-bold text-foreground mb-6">Transformers</h3>
            <ul className="space-y-3">
              {specifications.transformers.map((spec, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{spec}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-card p-8 rounded-2xl border border-border">
            <h3 className="text-xl font-bold text-foreground mb-6">Panels & Switchgear</h3>
            <ul className="space-y-3">
              {specifications.panels.map((spec, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-secondary shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{spec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
