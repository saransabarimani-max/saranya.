import { MapPin, Phone, Mail, Clock, MessageCircle, Globe } from "lucide-react"

const contactDetails = [
  {
    icon: MapPin,
    title: "Registered Office",
    details: ["No 4, Dr. Ambedkar Street", "Korattur, Ambattur", "Chennai, Tamil Nadu 600080", "India"],
  },
  {
    icon: Phone,
    title: "Phone Numbers",
    details: [
      "Landline: +91 44 2625 1234",
      "Mobile: +91 98401 12345",
      "Sales: +91 98401 12346",
      "Support: +91 98401 12347",
    ],
  },
  {
    icon: Mail,
    title: "Email Addresses",
    details: ["General: info@enmarkpower.com", "Sales: sales@enmarkpower.com", "Support: support@enmarkpower.com"],
  },
  {
    icon: Clock,
    title: "Business Hours",
    details: ["Monday - Friday: 9:00 AM - 6:00 PM", "Saturday: 9:00 AM - 2:00 PM", "Sunday: Closed"],
  },
]

export function ContactInfo() {
  return (
    <div className="space-y-6">
      {contactDetails.map((item, index) => (
        <div
          key={index}
          className="flex gap-4 p-6 bg-card border border-border rounded-xl hover:border-secondary/50 transition-colors"
        >
          <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center shrink-0">
            <item.icon className="w-6 h-6 text-secondary" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-card-foreground mb-2">{item.title}</h4>
            {item.details.map((detail, idx) => (
              <p key={idx} className="text-muted-foreground text-sm">
                {detail}
              </p>
            ))}
          </div>
        </div>
      ))}

      {/* WhatsApp Quick Contact */}
      <div className="bg-[#25D366]/10 border border-[#25D366]/30 rounded-xl p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-[#25D366] rounded-lg flex items-center justify-center">
            <MessageCircle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-foreground mb-1">WhatsApp Support</h4>
            <p className="text-muted-foreground text-sm mb-2">Get instant responses to your queries</p>
            <a
              href="https://wa.me/919840112345"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#25D366] font-semibold hover:underline"
            >
              Chat Now: +91 98401 12345
            </a>
          </div>
        </div>
      </div>

      {/* Company Info */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
            <Globe className="w-6 h-6 text-secondary" />
          </div>
          <div>
            <h4 className="font-semibold text-foreground">Company Details</h4>
            <p className="text-muted-foreground text-sm">Enmark Power Private Limited</p>
          </div>
        </div>
        <div className="space-y-1 text-sm text-muted-foreground">
          <p>CIN: U26109TN2023PTC162673</p>
          <p>Incorporation Date: August 9, 2023</p>
          <p>ROC: Chennai, Tamil Nadu</p>
          <p>GST: Available on request</p>
        </div>
      </div>
    </div>
  )
}
