import { Heart, Target, Lightbulb, Shield, Users, Leaf } from "lucide-react"

const values = [
  {
    icon: Heart,
    title: "Passion",
    description:
      "We are passionate about delivering excellence in every project we undertake, driven by our love for engineering and innovation.",
  },
  {
    icon: Target,
    title: "Precision",
    description:
      "Every detail matters. Our team ensures meticulous attention to specifications, tolerances, and quality standards.",
  },
  {
    icon: Lightbulb,
    title: "Innovation",
    description:
      "We continuously explore new technologies and methodologies to deliver cutting-edge power solutions to our clients.",
  },
  {
    icon: Shield,
    title: "Integrity",
    description:
      "Honesty and transparency form the foundation of our relationships with clients, partners, and team members.",
  },
  {
    icon: Users,
    title: "Collaboration",
    description:
      "We believe in the power of teamwork, fostering an environment where ideas are shared and excellence is achieved together.",
  },
  {
    icon: Leaf,
    title: "Sustainability",
    description:
      "Environmental responsibility guides our decisions, from product design to manufacturing processes and beyond.",
  },
]

export function TeamValues() {
  return (
    <section className="py-20 lg:py-32 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">What Drives Us</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Our Core Values
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            These principles guide everything we do at Enmark Power, shaping our culture and defining our commitment to
            excellence.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-2xl p-8 hover:shadow-lg hover:border-secondary/50 transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-secondary/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-secondary/20 transition-colors">
                <value.icon className="w-7 h-7 text-secondary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{value.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
