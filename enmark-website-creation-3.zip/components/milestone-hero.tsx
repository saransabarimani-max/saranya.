import { Calendar, Award, TrendingUp } from "lucide-react"

export function MilestoneHero() {
  return (
    <section className="pt-32 pb-20 bg-primary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full text-secondary text-sm font-medium mb-6">
            <Calendar className="w-4 h-4" />
            Established August 2023
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 text-balance">
            Our Journey of
            <span className="text-secondary"> Excellence</span>
          </h1>
          <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto mb-12 leading-relaxed text-pretty">
            From our inception in Tamil Nadu to becoming a trusted name in power solutions, every milestone represents
            our commitment to engineering excellence and customer satisfaction.
          </p>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div className="bg-primary-foreground/10 backdrop-blur-sm rounded-xl p-6 border border-primary-foreground/10">
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-6 h-6 text-secondary-foreground" />
              </div>
              <div className="text-3xl font-bold text-primary-foreground mb-1">Aug 2023</div>
              <div className="text-primary-foreground/60">Date of Incorporation</div>
            </div>
            <div className="bg-primary-foreground/10 backdrop-blur-sm rounded-xl p-6 border border-primary-foreground/10">
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mx-auto mb-4">
                <Award className="w-6 h-6 text-secondary-foreground" />
              </div>
              <div className="text-3xl font-bold text-primary-foreground mb-1">Active</div>
              <div className="text-primary-foreground/60">Company Status</div>
            </div>
            <div className="bg-primary-foreground/10 backdrop-blur-sm rounded-xl p-6 border border-primary-foreground/10">
              <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-secondary-foreground" />
              </div>
              <div className="text-3xl font-bold text-primary-foreground mb-1">₹50L</div>
              <div className="text-primary-foreground/60">Authorized Capital</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
