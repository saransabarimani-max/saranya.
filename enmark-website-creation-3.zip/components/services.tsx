import { Settings, Wrench, Truck, HeadphonesIcon, Cog, ClipboardCheck } from "lucide-react"

const services = [
  {
    icon: Settings,
    title: "Custom Engineering",
    description: "Tailored power solutions designed to meet your specific industrial requirements and specifications.",
  },
  {
    icon: Wrench,
    title: "Installation Services",
    description:
      "Professional installation by certified technicians ensuring optimal performance and safety compliance.",
  },
  {
    icon: Truck,
    title: "Pan-India Delivery",
    description: "Reliable logistics network ensuring timely delivery of equipment across all major industrial zones.",
  },
  {
    icon: HeadphonesIcon,
    title: "Technical Support",
    description: "Round-the-clock technical assistance and troubleshooting from our expert engineering team.",
  },
  {
    icon: Cog,
    title: "Maintenance Contracts",
    description: "Comprehensive AMC packages to ensure continuous operation and extend equipment lifespan.",
  },
  {
    icon: ClipboardCheck,
    title: "Compliance & Testing",
    description: "Complete testing and certification services to meet all regulatory and industry standards.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Services</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight text-balance">
            Comprehensive Support for Your Power Needs
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            From initial consultation to ongoing maintenance, we provide end-to-end services that ensure your power
            infrastructure operates at peak efficiency.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group p-8 bg-card border border-border rounded-xl hover:border-secondary/50 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-14 h-14 bg-secondary/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
                <service.icon className="w-7 h-7 text-secondary group-hover:text-secondary-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-card-foreground mb-3">{service.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
