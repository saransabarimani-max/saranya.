import { Target, Eye, Gem } from "lucide-react"

const missionVision = [
  {
    icon: Target,
    title: "Our Mission",
    content:
      "To deliver innovative, reliable, and sustainable power solutions that empower industries across India. We strive to exceed customer expectations through engineering excellence, superior quality, and exceptional service.",
  },
  {
    icon: Eye,
    title: "Our Vision",
    content:
      "To become India's most trusted partner for electrical infrastructure solutions by 2030. We aim to lead the industry in innovation, sustainability, and customer satisfaction while contributing to the nation's industrial growth.",
  },
  {
    icon: Gem,
    title: "Our Values",
    content:
      "Integrity, Innovation, Quality, and Customer Focus form the pillars of our organization. We believe in building lasting relationships through honest dealings, continuous improvement, and unwavering commitment to excellence.",
  },
]

export function AboutMission() {
  return (
    <section className="py-20 lg:py-32 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Purpose & Direction</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Driving Industrial Progress
          </h2>
          <p className="text-lg text-muted-foreground">
            Our mission, vision, and values guide every decision we make and every solution we deliver.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {missionVision.map((item, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-2xl p-8 hover:shadow-lg hover:border-secondary/50 transition-all duration-300"
            >
              <div className="w-16 h-16 bg-secondary rounded-2xl flex items-center justify-center mb-6">
                <item.icon className="w-8 h-8 text-secondary-foreground" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-4">{item.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{item.content}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
