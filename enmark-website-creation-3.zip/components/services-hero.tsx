import { Settings, Shield, Wrench } from "lucide-react"

export function ServicesHero() {
  return (
    <section className="relative pt-32 pb-20 bg-primary overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='0.3'%3E%3Cpath d='M50 50c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10s-10-4.477-10-10 4.477-10 10-10zM10 10c0-5.523 4.477-10 10-10s10 4.477 10 10-4.477 10-10 10c0 5.523-4.477 10-10 10S0 25.523 0 20s4.477-10 10-10z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full mb-6">
            <Settings className="w-4 h-4 text-secondary" />
            <span className="text-secondary text-sm font-medium">Our Services</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 text-balance">
            End-to-End Electrical
            <span className="text-secondary block mt-2">Solutions</span>
          </h1>

          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-10">
            From initial consultation to ongoing maintenance, we provide comprehensive services that ensure your
            electrical infrastructure operates at peak performance.
          </p>

          <div className="flex flex-wrap justify-center gap-6">
            <div className="flex items-center gap-2 px-4 py-2 bg-primary-foreground/10 rounded-lg">
              <Shield className="w-5 h-5 text-secondary" />
              <span className="text-primary-foreground">Safety First</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 bg-primary-foreground/10 rounded-lg">
              <Wrench className="w-5 h-5 text-secondary" />
              <span className="text-primary-foreground">Expert Team</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
