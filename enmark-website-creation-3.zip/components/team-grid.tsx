import { Linkedin, Mail, Phone } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

const leadershipTeam = [
  {
    name: "Rajesh Kumar",
    designation: "Founder & Managing Director",
    image: "/indian-businessman-professional-portrait.jpg",
    description:
      "With over 20 years of experience in the electrical industry, Rajesh founded Enmark Power with a vision to revolutionize power infrastructure in India. He holds a B.E. in Electrical Engineering from Anna University.",
    linkedin: "https://linkedin.com/in/",
    email: "rajesh@enmarkpower.com",
    phone: "+91 98401 12345",
  },
  {
    name: "Priya Sharma",
    designation: "Director - Operations",
    image: "/indian-businesswoman-professional-portrait.jpg",
    description:
      "Priya oversees all operational aspects of Enmark Power, ensuring seamless project delivery and quality standards. She brings 15+ years of experience in manufacturing operations.",
    linkedin: "https://linkedin.com/in/",
    email: "priya@enmarkpower.com",
    phone: "+91 98401 12346",
  },
  {
    name: "Venkatesh Iyer",
    designation: "Technical Director",
    image: "/indian-engineer-professional-portrait-man.jpg",
    description:
      "Venkatesh leads our engineering team with expertise in transformer design and power systems. He has successfully delivered over 100+ projects across various industries.",
    linkedin: "https://linkedin.com/in/",
    email: "venkatesh@enmarkpower.com",
    phone: "+91 98401 12347",
  },
]

const engineeringTeam = [
  {
    name: "Arun Balaji",
    designation: "Senior Design Engineer",
    image: "/indian-engineer-young-professional.jpg",
    specialization: "Transformer Design",
  },
  {
    name: "Deepika Natarajan",
    designation: "Project Engineer",
    image: "/indian-woman-engineer-professional.jpg",
    specialization: "Power Distribution",
  },
  {
    name: "Karthik Sundaram",
    designation: "Electrical Engineer",
    image: "/indian-male-engineer-professional-young.jpg",
    specialization: "Control Systems",
  },
  {
    name: "Meera Krishnan",
    designation: "Quality Engineer",
    image: "/indian-professional-woman-engineer-quality.jpg",
    specialization: "Testing & QA",
  },
  {
    name: "Suresh Raman",
    designation: "Site Engineer",
    image: "/indian-construction-engineer-professional.jpg",
    specialization: "Installation",
  },
  {
    name: "Lakshmi Venkat",
    designation: "R&D Engineer",
    image: "/indian-woman-scientist-engineer-research.jpg",
    specialization: "Innovation",
  },
]

export function TeamGrid() {
  return (
    <section className="py-20 lg:py-32 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Leadership Team */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Leadership</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Our Leadership Team</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Visionary leaders driving Enmark Power towards excellence in the electrical industry
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {leadershipTeam.map((member, index) => (
              <Card
                key={index}
                className="border-border overflow-hidden group hover:shadow-xl transition-all duration-300"
              >
                <div className="relative h-72 overflow-hidden">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-primary/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                    <div className="flex gap-3">
                      <Link
                        href={member.linkedin}
                        target="_blank"
                        className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center hover:bg-secondary transition-colors"
                      >
                        <Linkedin className="w-5 h-5 text-primary-foreground" />
                      </Link>
                      <Link
                        href={`mailto:${member.email}`}
                        className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center hover:bg-secondary transition-colors"
                      >
                        <Mail className="w-5 h-5 text-primary-foreground" />
                      </Link>
                      <Link
                        href={`tel:${member.phone}`}
                        className="w-10 h-10 bg-primary-foreground/20 rounded-full flex items-center justify-center hover:bg-secondary transition-colors"
                      >
                        <Phone className="w-5 h-5 text-primary-foreground" />
                      </Link>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-1">{member.name}</h3>
                  <p className="text-secondary font-medium mb-3">{member.designation}</p>
                  <p className="text-muted-foreground text-sm leading-relaxed">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Engineering Team */}
        <div>
          <div className="text-center mb-12">
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Engineering Excellence</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Our Engineering Team</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Skilled engineers and technicians who bring innovative solutions to every project
            </p>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {engineeringTeam.map((member, index) => (
              <div key={index} className="group text-center">
                <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden border-4 border-border group-hover:border-secondary transition-colors">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h4 className="font-semibold text-foreground text-sm">{member.name}</h4>
                <p className="text-muted-foreground text-xs mb-1">{member.designation}</p>
                <span className="inline-block px-2 py-1 bg-secondary/10 text-secondary text-xs rounded-full">
                  {member.specialization}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
