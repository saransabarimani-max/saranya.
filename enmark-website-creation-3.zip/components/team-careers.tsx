import { ArrowRight, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

const openings = [
  {
    title: "Senior Electrical Engineer",
    department: "Engineering",
    location: "Chennai, Tamil Nadu",
    type: "Full-time",
    description: "Lead electrical design projects and mentor junior engineers in transformer and switchgear design.",
  },
  {
    title: "Project Manager",
    department: "Operations",
    location: "Chennai, Tamil Nadu",
    type: "Full-time",
    description: "Manage end-to-end project delivery for industrial electrical installations across South India.",
  },
  {
    title: "Quality Control Inspector",
    department: "Quality Assurance",
    location: "Chennai, Tamil Nadu",
    type: "Full-time",
    description: "Ensure all products meet IS/IEC standards through rigorous testing and inspection protocols.",
  },
]

export function TeamCareers() {
  return (
    <section className="py-20 lg:py-32 bg-primary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Content */}
          <div>
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Join Our Team</p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-primary-foreground mb-6 text-balance">
              Build Your Career with Enmark Power
            </h2>
            <p className="text-primary-foreground/80 text-lg mb-8 leading-relaxed">
              We are always looking for talented individuals who share our passion for engineering excellence and
              innovation. Join us and be part of a team that is shaping the future of India power infrastructure.
            </p>
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <div className="w-2 h-2 bg-secondary rounded-full" />
                <span>Competitive compensation and benefits</span>
              </div>
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <div className="w-2 h-2 bg-secondary rounded-full" />
                <span>Professional development opportunities</span>
              </div>
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <div className="w-2 h-2 bg-secondary rounded-full" />
                <span>Work on challenging, impactful projects</span>
              </div>
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <div className="w-2 h-2 bg-secondary rounded-full" />
                <span>Collaborative and supportive work environment</span>
              </div>
            </div>
            <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground" asChild>
              <Link href="mailto:careers@enmarkpower.com">
                Send Your Resume
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>

          {/* Current Openings */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-primary-foreground mb-6">Current Openings</h3>
            {openings.map((job, index) => (
              <Card
                key={index}
                className="bg-primary-foreground/5 border-primary-foreground/10 hover:bg-primary-foreground/10 transition-colors"
              >
                <CardContent className="p-6">
                  <div className="flex flex-wrap items-start justify-between gap-4 mb-3">
                    <div>
                      <h4 className="text-lg font-semibold text-primary-foreground">{job.title}</h4>
                      <p className="text-secondary text-sm">{job.department}</p>
                    </div>
                    <span className="px-3 py-1 bg-secondary/20 text-secondary text-xs font-medium rounded-full">
                      {job.type}
                    </span>
                  </div>
                  <p className="text-primary-foreground/70 text-sm mb-4">{job.description}</p>
                  <div className="flex flex-wrap gap-4 text-sm text-primary-foreground/60">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {job.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Posted Recently
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
            <p className="text-primary-foreground/60 text-sm pt-4">
              Don&apos;t see a suitable position? Send your resume to{" "}
              <Link href="mailto:careers@enmarkpower.com" className="text-secondary hover:underline">
                careers@enmarkpower.com
              </Link>
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
