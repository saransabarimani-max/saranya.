import { Zap, Users, Award, Clock } from "lucide-react"

const stats = [
  {
    icon: Zap,
    value: "5+ MW",
    label: "Total Capacity Installed",
  },
  {
    icon: Users,
    value: "20+",
    label: "Satisfied Clients",
  },
  {
    icon: Award,
    value: "100%",
    label: "Project Success Rate",
  },
  {
    icon: Clock,
    value: "< 30 Days",
    label: "Average Delivery Time",
  },
]

export function ProjectsStats() {
  return (
    <section className="py-12 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="w-14 h-14 bg-secondary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-7 h-7 text-secondary" />
              </div>
              <p className="text-2xl md:text-3xl font-bold text-foreground mb-1">{stat.value}</p>
              <p className="text-muted-foreground text-sm">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
