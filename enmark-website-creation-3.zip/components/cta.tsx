import { ArrowRight, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Cta() {
  return (
    <section className="py-20 lg:py-32 bg-primary relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="/industrial-power-electrical-infrastructure-modern.jpg"
          alt="Enmark Power Solutions"
          className="w-full h-full object-cover opacity-10"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-primary-foreground mb-6 text-balance">
          Ready to Power Your Next Project?
        </h2>
        <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto leading-relaxed mb-10">
          Partner with Enmark Power for reliable, innovative electrical solutions. Our team of experts is ready to help
          you find the perfect power infrastructure for your industrial needs.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            size="lg"
            className="bg-secondary hover:bg-secondary/90 text-secondary-foreground px-8 py-6 text-lg"
            asChild
          >
            <Link href="/contact">
              Get a Free Quote
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 px-8 py-6 text-lg bg-transparent"
            asChild
          >
            <a href="tel:+914426251234">
              <Phone className="mr-2 w-5 h-5" />
              Call: +91 44 2625 1234
            </a>
          </Button>
        </div>

        <div className="mt-12 grid sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 rounded-xl p-6">
            <p className="text-4xl font-bold text-secondary mb-2">500+</p>
            <p className="text-primary-foreground/80">Products Delivered</p>
          </div>
          <div className="bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 rounded-xl p-6">
            <p className="text-4xl font-bold text-secondary mb-2">50+</p>
            <p className="text-primary-foreground/80">Active Clients</p>
          </div>
          <div className="bg-primary-foreground/10 backdrop-blur-sm border border-primary-foreground/20 rounded-xl p-6">
            <p className="text-4xl font-bold text-secondary mb-2">24/7</p>
            <p className="text-primary-foreground/80">Technical Support</p>
          </div>
        </div>
      </div>
    </section>
  )
}
