import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

const products = [
  {
    name: "Power Transformers",
    description: "High-efficiency transformers from 11kV to 220kV range with ONAN/ONAF cooling systems.",
    image: "/industrial-power-transformer-electrical-equipment-.jpg",
  },
  {
    name: "Distribution Panels",
    description: "IP65 rated panels with smart monitoring and modular design for industrial applications.",
    image: "/electrical-distribution-panel-switchgear-industria.jpg",
  },
  {
    name: "Industrial Switchgear",
    description: "Advanced switchgear with arc flash protection and remote operation capabilities.",
    image: "/industrial-switchgear-electrical-cabinet-high-volt.jpg",
  },
  {
    name: "Control Systems",
    description: "SCADA-integrated IoT-enabled control systems for 24/7 automated monitoring.",
    image: "/industrial-control-system-automation-panel-plc-sca.jpg",
  },
]

export function HomeProducts() {
  return (
    <section className="py-20 lg:py-32 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-16">
          <div>
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Products</p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight">
              Power Solutions Built
              <span className="block">for Performance</span>
            </h2>
            <p className="text-muted-foreground mt-4 max-w-xl">
              We manufacture and supply a comprehensive range of electrical equipment designed for reliability,
              efficiency, and long-term performance.
            </p>
          </div>
          <Button
            variant="outline"
            className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground w-fit bg-transparent"
            asChild
          >
            <Link href="/products">
              View All Products
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <Card
              key={index}
              className="group overflow-hidden border-border hover:border-secondary/50 transition-all duration-300"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <CardContent className="p-5">
                <h3 className="font-semibold text-foreground mb-2 group-hover:text-secondary transition-colors">
                  {product.name}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
