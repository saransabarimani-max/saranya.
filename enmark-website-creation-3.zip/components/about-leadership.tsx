import { Linkedin, Mail } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

const directors = [
  {
    name: "Rajesh Kumar",
    designation: "Founder & Managing Director",
    image: "/placeholder.svg?height=400&width=400",
    description:
      "With over 20 years of experience in the electrical industry, Rajesh founded Enmark Power with a vision to revolutionize power infrastructure in India. He holds a B.E. in Electrical Engineering from Anna University and has previously held leadership positions at leading transformer manufacturing companies.",
    linkedin: "https://www.linkedin.com/in/",
    email: "rajesh@enmarkpower.com",
  },
  {
    name: "Priya Sharma",
    designation: "Director - Operations",
    image: "/placeholder.svg?height=400&width=400",
    description:
      "Priya oversees all operational aspects of Enmark Power, ensuring seamless project delivery and adherence to quality standards. With 15+ years of experience in manufacturing operations, she brings expertise in process optimization and supply chain management.",
    linkedin: "https://www.linkedin.com/in/",
    email: "priya@enmarkpower.com",
  },
]

export function AboutLeadership() {
  return (
    <section className="py-20 lg:py-32 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Leadership</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Meet Our Directors</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our leadership team brings decades of combined experience in the electrical industry.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {directors.map((director, index) => (
            <Card key={index} className="overflow-hidden border-border">
              <div className="relative h-72 overflow-hidden">
                <img
                  src={director.image || "/placeholder.svg"}
                  alt={director.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-foreground mb-1">{director.name}</h3>
                <p className="text-secondary font-medium mb-4">{director.designation}</p>
                <p className="text-muted-foreground text-sm leading-relaxed mb-4">{director.description}</p>
                <div className="flex gap-3">
                  <Link
                    href={director.linkedin}
                    target="_blank"
                    className="w-10 h-10 bg-muted rounded-full flex items-center justify-center hover:bg-secondary hover:text-secondary-foreground transition-colors"
                  >
                    <Linkedin className="w-5 h-5" />
                  </Link>
                  <Link
                    href={`mailto:${director.email}`}
                    className="w-10 h-10 bg-muted rounded-full flex items-center justify-center hover:bg-secondary hover:text-secondary-foreground transition-colors"
                  >
                    <Mail className="w-5 h-5" />
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
