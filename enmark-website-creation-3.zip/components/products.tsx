"use client"

import { useState } from "react"
import { ArrowRight, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const products = [
  {
    id: 1,
    name: "Power Transformers",
    category: "Transformers",
    description:
      "High-efficiency power transformers designed for industrial and commercial applications with superior insulation and cooling systems.",
    image: "/industrial-power-transformer-electrical-equipment-.jpg",
    features: ["11kV to 220kV range", "ONAN/ONAF cooling", "ISO certified"],
  },
  {
    id: 2,
    name: "Distribution Panels",
    category: "Panels",
    description:
      "Robust distribution panels engineered for optimal power management and safety in demanding environments.",
    image: "/electrical-distribution-panel-switchgear-industria.jpg",
    features: ["IP65 rated", "Smart monitoring", "Modular design"],
  },
  {
    id: 3,
    name: "Industrial Switchgear",
    category: "Switchgear",
    description:
      "Advanced switchgear solutions for reliable power distribution and protection across industrial facilities.",
    image: "/industrial-switchgear-electrical-cabinet-high-volt.jpg",
    features: ["Arc flash protection", "Remote operation", "Low maintenance"],
  },
  {
    id: 4,
    name: "Control Systems",
    category: "Automation",
    description: "Intelligent control systems for automated power management and real-time monitoring capabilities.",
    image: "/industrial-control-system-automation-panel-plc-sca.jpg",
    features: ["SCADA integration", "IoT enabled", "24/7 monitoring"],
  },
]

export function Products() {
  const [activeProduct, setActiveProduct] = useState(0)

  return (
    <section id="products" className="py-20 lg:py-32 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-16">
          <div>
            <p className="text-secondary font-semibold mb-4 tracking-wide uppercase">Our Products</p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground tracking-tight">
              Power Solutions Built
              <span className="block">for Performance</span>
            </h2>
          </div>
          <Button
            variant="outline"
            className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground w-fit bg-transparent"
          >
            View All Products
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>

        {/* Products Grid */}
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Product List */}
          <div className="space-y-4">
            {products.map((product, index) => (
              <button
                key={product.id}
                onClick={() => setActiveProduct(index)}
                className={cn(
                  "w-full text-left p-6 rounded-xl border transition-all duration-300",
                  activeProduct === index
                    ? "bg-card border-secondary shadow-lg"
                    : "bg-card/50 border-border hover:border-secondary/50",
                )}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-sm text-secondary font-medium">{product.category}</span>
                    <h3 className="text-xl font-semibold text-card-foreground mt-1">{product.name}</h3>
                    <p className="text-muted-foreground mt-2 line-clamp-2">{product.description}</p>
                  </div>
                  <ChevronRight
                    className={cn(
                      "w-5 h-5 text-secondary transition-transform",
                      activeProduct === index && "rotate-90",
                    )}
                  />
                </div>
              </button>
            ))}
          </div>

          {/* Product Preview */}
          <div className="sticky top-24">
            <div className="bg-card border border-border rounded-2xl overflow-hidden">
              <img
                src={products[activeProduct].image || "/placeholder.svg"}
                alt={products[activeProduct].name}
                className="w-full h-[300px] object-cover"
              />
              <div className="p-6">
                <h3 className="text-2xl font-bold text-card-foreground mb-3">{products[activeProduct].name}</h3>
                <p className="text-muted-foreground mb-6">{products[activeProduct].description}</p>
                <div className="flex flex-wrap gap-2 mb-6">
                  {products[activeProduct].features.map((feature, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-secondary/10 text-secondary text-sm font-medium rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
                <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground w-full">
                  Request Specifications
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
