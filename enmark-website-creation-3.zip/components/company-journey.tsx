import Image from "next/image"
import { CheckCircle2 } from "lucide-react"

const achievements = [
  "Registered as Private Limited Company with ROC Chennai",
  "Authorized Share Capital of ₹50,00,000",
  "Paid Up Capital of ₹50,00,000",
  "Active Company Status with Ministry of Corporate Affairs",
  "Established manufacturing infrastructure in Ambattur",
  "Built network of certified suppliers and partners",
  "Developed comprehensive product portfolio",
  "Created employment opportunities in Tamil Nadu",
]

export function CompanyJourney() {
  return (
    <section className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden">
              <Image
                src="/modern-industrial-power-manufacturing-facility-wit.jpg"
                alt="Enmark Power Manufacturing Facility"
                fill
                className="object-cover"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 bg-secondary text-secondary-foreground p-6 rounded-xl shadow-xl max-w-[200px]">
              <div className="text-4xl font-bold">2+</div>
              <div className="text-secondary-foreground/80">Years of Excellence</div>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="text-secondary font-semibold text-sm tracking-wider uppercase">Our Journey</span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-6 text-balance">
              From Vision to Reality
            </h2>
            <p className="text-muted-foreground mb-8 text-lg leading-relaxed text-pretty">
              Enmark Power Private Limited embarked on its journey in August 2023 with a clear vision to transform the
              power solutions landscape in India. Registered with the Registrar of Companies, Chennai, we have steadily
              built our capabilities and reputation in the industry.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {achievements.map((achievement, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
                  <span className="text-foreground text-sm">{achievement}</span>
                </div>
              ))}
            </div>

            {/* Company Info Card */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h4 className="font-semibold text-foreground mb-4">Corporate Information</h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">CIN</span>
                  <span className="text-foreground font-mono">U26109TN2023PTC162673</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Entity Type</span>
                  <span className="text-foreground">Private Limited Company</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Registrar</span>
                  <span className="text-foreground">ROC - Chennai</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Company Age</span>
                  <span className="text-foreground">2 Years 4 Months</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
