import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Lightbulb, Wrench, Settings, HeadphonesIcon, ClipboardCheck, Truck, Shield, Gauge } from "lucide-react"

const services = [
  {
    icon: Lightbulb,
    title: "Electrical Design & Engineering",
    description:
      "Custom electrical system design tailored to your facility's unique requirements, ensuring optimal efficiency and compliance with Indian electrical codes.",
    features: [
      "Load calculation & analysis",
      "Single line diagram preparation",
      "Equipment specification",
      "Energy efficiency optimization",
    ],
  },
  {
    icon: Wrench,
    title: "Installation & Commissioning",
    description:
      "Professional installation of all electrical equipment with meticulous attention to safety standards and manufacturer specifications.",
    features: [
      "Transformer installation",
      "Panel board erection",
      "Cable laying & termination",
      "Testing & commissioning",
    ],
  },
  {
    icon: Settings,
    title: "Preventive Maintenance",
    description:
      "Scheduled maintenance programs to prevent equipment failures, extend asset life, and ensure uninterrupted operations.",
    features: [
      "Periodic inspections",
      "Thermal imaging surveys",
      "Oil testing & treatment",
      "Contact resistance testing",
    ],
  },
  {
    icon: HeadphonesIcon,
    title: "24/7 Technical Support",
    description:
      "Round-the-clock emergency response and technical assistance to minimize downtime and resolve issues promptly.",
    features: [
      "Emergency breakdown service",
      "Remote troubleshooting",
      "On-site technical support",
      "Spare parts availability",
    ],
  },
  {
    icon: ClipboardCheck,
    title: "Electrical Audits & Consulting",
    description:
      "Comprehensive electrical system audits to identify inefficiencies, safety hazards, and opportunities for improvement.",
    features: ["Energy audit services", "Safety compliance audit", "Power quality analysis", "Upgrade recommendations"],
  },
  {
    icon: Truck,
    title: "Equipment Supply",
    description:
      "Quality electrical equipment sourcing from trusted manufacturers with warranty support and competitive pricing.",
    features: ["Transformers & switchgear", "Distribution panels", "Cables & accessories", "Protection devices"],
  },
  {
    icon: Shield,
    title: "Safety Systems",
    description:
      "Design and implementation of comprehensive electrical safety systems to protect personnel and equipment.",
    features: [
      "Earthing & lightning protection",
      "Fire detection systems",
      "Emergency power systems",
      "Safety interlocks",
    ],
  },
  {
    icon: Gauge,
    title: "Energy Management",
    description:
      "Smart energy management solutions to monitor, analyze, and optimize your facility's power consumption.",
    features: ["Smart metering installation", "SCADA integration", "Power factor correction", "Demand management"],
  },
]

export function ServicesDetail() {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What We Offer</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Comprehensive electrical services designed to meet the diverse needs of industrial and commercial clients.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="group border-border hover:border-secondary/50 transition-all duration-300 hover:shadow-lg"
            >
              <CardHeader className="pb-4">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-secondary/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-secondary/20 transition-colors">
                    <service.icon className="w-7 h-7 text-secondary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl text-foreground group-hover:text-secondary transition-colors">
                      {service.title}
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">{service.description}</p>
                <ul className="grid grid-cols-2 gap-2">
                  {service.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="w-1.5 h-1.5 bg-secondary rounded-full" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
