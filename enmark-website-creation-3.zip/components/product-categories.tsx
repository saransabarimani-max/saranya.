"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const categories = [
  { id: "all", label: "All Products", count: 12 },
  { id: "transformers", label: "Transformers", count: 4 },
  { id: "panels", label: "Distribution Panels", count: 3 },
  { id: "switchgear", label: "Switchgear", count: 3 },
  { id: "control", label: "Control Systems", count: 2 },
]

export function ProductCategories() {
  const [activeCategory, setActiveCategory] = useState("all")

  return (
    <section className="py-12 bg-muted border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap justify-center gap-3">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={cn(
                "px-6 py-3 rounded-full font-medium transition-all",
                activeCategory === category.id
                  ? "bg-secondary text-secondary-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground border border-border",
              )}
            >
              {category.label}
              <span className="ml-2 text-sm opacity-70">({category.count})</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}
