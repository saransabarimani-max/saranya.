import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, Mail, ArrowRight } from "lucide-react"

export function ServicesCta() {
  return (
    <section className="py-20 bg-primary">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Ready to Power Your Project?</h2>
        <p className="text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
          Contact our team today for a free consultation and discover how Enmark Power can deliver reliable electrical
          solutions for your facility.
        </p>

        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground gap-2">
            <Phone className="w-5 h-5" />
            Request Callback
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 gap-2 bg-transparent"
            asChild
          >
            <Link href="/#contact">
              <Mail className="w-5 h-5" />
              Send Inquiry
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>

        <p className="text-primary-foreground/60 text-sm">
          CIN: U26109TN2023PTC162673 | Registered in Tamil Nadu, India
        </p>
      </div>
    </section>
  )
}
