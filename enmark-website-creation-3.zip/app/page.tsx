import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { HomeAbout } from "@/components/home-about"
import { HomeProducts } from "@/components/home-products"
import { Stats } from "@/components/stats"
import { HomeServices } from "@/components/home-services"
import { Testimonials } from "@/components/testimonials"
import { Certifications } from "@/components/certifications"
import { WhyChooseUs } from "@/components/why-choose-us"
import { Partners } from "@/components/partners"
import { Cta } from "@/components/cta"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <HomeAbout />
      <Stats />
      <HomeProducts />
      <HomeServices />
      <WhyChooseUs />
      <Testimonials />
      <Certifications />
      <Partners />
      <Cta />
      <Footer />
    </main>
  )
}
