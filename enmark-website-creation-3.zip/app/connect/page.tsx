import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Users,
  Linkedin,
  Twitter,
  Facebook,
  Instagram,
  Youtube,
  Mail,
  Phone,
  MapPin,
  Clock,
  MessageCircle,
  Send,
  Globe,
} from "lucide-react"

export const metadata = {
  title: "Connect With Us | Enmark Power",
  description: "Follow Enmark Power on social media and stay connected with our latest updates and news.",
}

const socialPlatforms = [
  {
    name: "LinkedIn",
    icon: Linkedin,
    url: "https://www.linkedin.com/company/enmark-power",
    handle: "@enmark-power",
    description: "Professional updates, industry insights, job opportunities, and company news",
    color: "bg-[#0077B5]",
    followers: "500+",
    cta: "Follow",
  },
  {
    name: "Twitter / X",
    icon: Twitter,
    url: "https://twitter.com/enmarkpower",
    handle: "@enmarkpower",
    description: "Real-time updates, industry news, and engaging discussions about power solutions",
    color: "bg-[#000000]",
    followers: "250+",
    cta: "Follow",
  },
  {
    name: "Facebook",
    icon: Facebook,
    url: "https://www.facebook.com/enmarkpower",
    handle: "@enmarkpower",
    description: "Company news, events, project showcases, and community engagement",
    color: "bg-[#1877F2]",
    followers: "400+",
    cta: "Like",
  },
  {
    name: "Instagram",
    icon: Instagram,
    url: "https://www.instagram.com/enmarkpower",
    handle: "@enmarkpower",
    description: "Behind-the-scenes, project photos, team moments, and visual stories",
    color: "bg-gradient-to-br from-[#833AB4] via-[#FD1D1D] to-[#F77737]",
    followers: "300+",
    cta: "Follow",
  },
  {
    name: "YouTube",
    icon: Youtube,
    url: "https://www.youtube.com/@enmarkpower",
    handle: "@enmarkpower",
    description: "Product demos, installation guides, tutorials, and company videos",
    color: "bg-[#FF0000]",
    followers: "150+",
    cta: "Subscribe",
  },
  {
    name: "Website",
    icon: Globe,
    url: "https://www.enmarkpower.com",
    handle: "enmarkpower.com",
    description: "Visit our official website for detailed product information and services",
    color: "bg-secondary",
    followers: "24/7",
    cta: "Visit",
  },
]

const contactMethods = [
  {
    icon: Phone,
    title: "Landline",
    value: "+91 44 2625 1234",
    description: "Mon-Sat, 9AM-6PM IST",
    link: "tel:+914426251234",
  },
  {
    icon: Phone,
    title: "Mobile",
    value: "+91 98401 12345",
    description: "Sales & General Enquiries",
    link: "tel:+919840112345",
  },
  {
    icon: Mail,
    title: "Email",
    value: "info@enmarkpower.com",
    description: "We respond within 24 hours",
    link: "mailto:info@enmarkpower.com",
  },
  {
    icon: MessageCircle,
    title: "WhatsApp",
    value: "+91 98401 12345",
    description: "Quick queries and support",
    link: "https://wa.me/919840112345",
  },
]

export default function ConnectPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="pt-32 pb-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full mb-6">
            <Users className="w-4 h-4 text-secondary" />
            <span className="text-secondary text-sm font-medium">Stay Connected</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6 text-balance">
            Let&apos;s Connect &<span className="text-secondary block mt-2">Grow Together</span>
          </h1>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto leading-relaxed">
            Follow us on social media for the latest updates, industry insights, project showcases, and
            behind-the-scenes content from Enmark Power. Join our growing community of industry professionals.
          </p>
        </div>
      </section>

      {/* Social Media Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Follow Us on Social Media</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Join our growing community across social platforms and stay updated with our latest projects, products,
              and industry insights.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {socialPlatforms.map((platform) => (
              <Card
                key={platform.name}
                className="group border-border hover:border-secondary/50 transition-all duration-300 hover:shadow-lg overflow-hidden"
              >
                <CardContent className="p-0">
                  <div className={`${platform.color} p-6`}>
                    <div className="flex items-center justify-between">
                      <platform.icon className="w-10 h-10 text-primary-foreground" />
                      <span className="text-primary-foreground/80 text-sm">{platform.followers} followers</span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-1">{platform.name}</h3>
                    <p className="text-secondary text-sm mb-3">{platform.handle}</p>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">{platform.description}</p>
                    <Button
                      variant="outline"
                      className="w-full gap-2 group-hover:border-secondary group-hover:text-secondary bg-transparent"
                      asChild
                    >
                      <Link href={platform.url} target="_blank" rel="noopener noreferrer">
                        <Send className="w-4 h-4" />
                        {platform.cta}
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Contact */}
      <section className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Quick Contact</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Reach out to us through your preferred channel. Our team is available Monday to Saturday from 9 AM to 6 PM
              IST.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {contactMethods.map((method, index) => (
              <Card key={index} className="text-center border-border hover:border-secondary/50 transition-colors">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-secondary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <method.icon className="w-7 h-7 text-secondary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-1">{method.title}</h3>
                  <a href={method.link} className="text-secondary font-medium mb-2 block hover:underline">
                    {method.value}
                  </a>
                  <p className="text-muted-foreground text-sm">{method.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Office Location */}
          <Card className="border-border overflow-hidden">
            <CardContent className="p-0">
              <div className="grid md:grid-cols-2">
                <div className="p-8">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-foreground">Visit Our Office</h3>
                      <p className="text-muted-foreground text-sm">Registered Office</p>
                    </div>
                  </div>
                  <address className="not-italic text-muted-foreground mb-6 space-y-1">
                    <p className="font-semibold text-foreground text-lg">Enmark Power Private Limited</p>
                    <p>No 4, Dr. Ambedkar Street</p>
                    <p>Korattur, Ambattur</p>
                    <p>Chennai, Tamil Nadu - 600080</p>
                    <p>India</p>
                  </address>
                  <div className="flex items-center gap-2 text-muted-foreground mb-6">
                    <Clock className="w-4 h-4 text-secondary" />
                    <span>Mon - Sat: 9:00 AM - 6:00 PM IST</span>
                  </div>
                  <Button variant="outline" className="bg-transparent" asChild>
                    <Link
                      href="https://maps.google.com/?q=Korattur,Ambattur,Chennai,Tamil+Nadu+600080"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <MapPin className="w-4 h-4 mr-2" />
                      Get Directions
                    </Link>
                  </Button>
                </div>
                <div className="h-64 md:h-auto bg-muted relative">
                  <img src="/map-chennai-ambattur-industrial-area-satellite.jpg" alt="Office Location" className="w-full h-full object-cover" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 bg-primary">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Mail className="w-16 h-16 text-secondary mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">Subscribe to Our Newsletter</h2>
          <p className="text-primary-foreground/80 mb-8 leading-relaxed">
            Get the latest updates on our products, projects, industry insights, and exclusive offers delivered directly
            to your inbox. Join 1000+ industry professionals who trust Enmark Power.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 px-4 py-3 rounded-lg bg-primary-foreground/10 border border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50 focus:outline-none focus:border-secondary"
            />
            <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground px-8">Subscribe</Button>
          </div>
          <p className="text-primary-foreground/50 text-sm mt-4">We respect your privacy. Unsubscribe at any time.</p>
        </div>
      </section>

      <Footer />
    </main>
  )
}
