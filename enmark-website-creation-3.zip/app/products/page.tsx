import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductsHero } from "@/components/products-hero"
import { ProductsShowcase } from "@/components/products-showcase"
import { ProductCategories } from "@/components/product-categories"
import { ProductSpecs } from "@/components/product-specs"
import { ProductsCta } from "@/components/products-cta"

export const metadata = {
  title: "Products | Enmark Power",
  description:
    "Explore our comprehensive range of power transformers, distribution panels, switchgear, and control systems.",
}

export default function ProductsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <ProductsHero />
      <ProductCategories />
      <ProductsShowcase />
      <ProductSpecs />
      <ProductsCta />
      <Footer />
    </main>
  )
}
