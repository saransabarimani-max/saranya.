import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AboutHero } from "@/components/about-hero"
import { AboutStory } from "@/components/about-story"
import { AboutHistory } from "@/components/about-history"
import { AboutMission } from "@/components/about-mission"
import { AboutCertifications } from "@/components/about-certifications"
import { AboutLeadership } from "@/components/about-leadership"
import { AboutCta } from "@/components/about-cta"

export const metadata = {
  title: "About Us | Enmark Power Private Limited",
  description:
    "Learn about Enmark Power Private Limited - our history, mission, vision, and commitment to excellence in power solutions since 2023.",
}

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <AboutHero />
      <AboutStory />
      <AboutHistory />
      <AboutMission />
      <AboutLeadership />
      <AboutCertifications />
      <AboutCta />
      <Footer />
    </main>
  )
}
