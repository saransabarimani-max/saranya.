import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ServicesHero } from "@/components/services-hero"
import { ServicesDetail } from "@/components/services-detail"
import { ServiceProcess } from "@/components/service-process"
import { ServicesCta } from "@/components/services-cta"

export const metadata = {
  title: "Services | Enmark Power",
  description: "Comprehensive electrical engineering and power solutions services by Enmark Power Private Limited.",
}

export default function ServicesPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <ServicesHero />
      <ServicesDetail />
      <ServiceProcess />
      <ServicesCta />
      <Footer />
    </main>
  )
}
