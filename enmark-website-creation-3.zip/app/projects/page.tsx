import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProjectsHero } from "@/components/projects-hero"
import { ProjectsGrid } from "@/components/projects-grid"
import { ProjectsStats } from "@/components/projects-stats"
import { ClientLogos } from "@/components/client-logos"

export const metadata = {
  title: "Projects | Enmark Power",
  description: "Explore our portfolio of successful power infrastructure projects across India.",
}

export default function ProjectsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <ProjectsHero />
      <ProjectsStats />
      <ProjectsGrid />
      <ClientLogos />
      <Footer />
    </main>
  )
}
