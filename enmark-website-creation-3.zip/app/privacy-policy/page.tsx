import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Shield } from "lucide-react"

export const metadata = {
  title: "Privacy Policy | Enmark Power",
  description: "Privacy Policy of Enmark Power Private Limited - How we collect, use, and protect your information.",
}

export default function PrivacyPolicyPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="pt-32 pb-12 bg-primary">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary/20 rounded-full mb-6">
            <Shield className="w-4 h-4 text-secondary" />
            <span className="text-secondary text-sm font-medium">Legal</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">Privacy Policy</h1>
          <p className="text-primary-foreground/80">Last updated: January 2026</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg max-w-none">
            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Introduction</h2>
              <p className="text-muted-foreground mb-4">
                Enmark Power Private Limited (&quot;we,&quot; &quot;our,&quot; or &quot;us&quot;) is committed to
                protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your
                information when you visit our website or use our services.
              </p>
              <p className="text-muted-foreground">
                <strong className="text-foreground">Company Details:</strong>
                <br />
                CIN: U26109TN2023PTC162673
                <br />
                Registered Office: No 4 Dr.Ambedkar Street, Korattur, Ambattur, Chennai, Tamil Nadu - 600080
              </p>
            </div>

            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Information We Collect</h2>
              <h3 className="text-lg font-semibold text-foreground mt-6 mb-3">Personal Information</h3>
              <p className="text-muted-foreground mb-4">
                We may collect personal information that you voluntarily provide to us when you:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
                <li>Fill out contact forms or request quotes</li>
                <li>Subscribe to our newsletter</li>
                <li>Communicate with us via email or phone</li>
                <li>Enter into a business relationship with us</li>
              </ul>
              <p className="text-muted-foreground">
                This information may include your name, email address, phone number, company name, and project details.
              </p>

              <h3 className="text-lg font-semibold text-foreground mt-6 mb-3">Automatically Collected Information</h3>
              <p className="text-muted-foreground">
                When you visit our website, we may automatically collect certain information including your IP address,
                browser type, operating system, referring URLs, and pages viewed.
              </p>
            </div>

            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">How We Use Your Information</h2>
              <p className="text-muted-foreground mb-4">We use the information we collect to:</p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Respond to your inquiries and provide customer support</li>
                <li>Process your requests for quotes and services</li>
                <li>Send you updates about our products and services (with your consent)</li>
                <li>Improve our website and services</li>
                <li>Comply with legal obligations</li>
                <li>Protect against fraudulent or illegal activity</li>
              </ul>
            </div>

            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Information Sharing</h2>
              <p className="text-muted-foreground mb-4">
                We do not sell, trade, or rent your personal information to third parties. We may share your information
                only in the following circumstances:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>With service providers who assist us in operating our business</li>
                <li>To comply with legal requirements or respond to lawful requests</li>
                <li>To protect our rights, privacy, safety, or property</li>
                <li>In connection with a merger, acquisition, or sale of assets</li>
              </ul>
            </div>

            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Data Security</h2>
              <p className="text-muted-foreground">
                We implement appropriate technical and organizational security measures to protect your personal
                information against unauthorized access, alteration, disclosure, or destruction. However, no method of
                transmission over the Internet or electronic storage is 100% secure.
              </p>
            </div>

            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Your Rights</h2>
              <p className="text-muted-foreground mb-4">
                Under applicable data protection laws, you may have the right to:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2">
                <li>Access the personal information we hold about you</li>
                <li>Request correction of inaccurate information</li>
                <li>Request deletion of your personal information</li>
                <li>Object to or restrict processing of your information</li>
                <li>Withdraw consent where processing is based on consent</li>
              </ul>
            </div>

            <div className="bg-card rounded-xl border border-border p-8 mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Cookies</h2>
              <p className="text-muted-foreground">
                Our website may use cookies and similar tracking technologies to enhance your browsing experience. You
                can set your browser to refuse cookies, but this may limit some features of our website.
              </p>
            </div>

            <div className="bg-card rounded-xl border border-border p-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">Contact Us</h2>
              <p className="text-muted-foreground mb-4">
                If you have any questions about this Privacy Policy or our data practices, please contact us at:
              </p>
              <div className="text-muted-foreground">
                <p>
                  <strong className="text-foreground">Enmark Power Private Limited</strong>
                </p>
                <p>No 4 Dr.Ambedkar Street, Korattur</p>
                <p>Ambattur, Chennai, Tamil Nadu - 600080</p>
                <p className="mt-2">Email: privacy@enmarkpower.com</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
