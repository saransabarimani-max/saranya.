import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { TeamHero } from "@/components/team-hero"
import { TeamGrid } from "@/components/team-grid"
import { TeamValues } from "@/components/team-values"
import { TeamCareers } from "@/components/team-careers"

export const metadata = {
  title: "Our Team | Enmark Power",
  description:
    "Meet the talented professionals behind Enmark Power's success - our leadership, engineers, and technical experts.",
}

export default function TeamPage() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <TeamHero />
      <TeamGrid />
      <TeamValues />
      <TeamCareers />
      <Footer />
    </main>
  )
}
