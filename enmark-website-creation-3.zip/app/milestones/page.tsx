import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { MilestoneTimeline } from "@/components/milestone-timeline"
import { MilestoneHero } from "@/components/milestone-hero"
import { CompanyJourney } from "@/components/company-journey"
import { FutureVision } from "@/components/future-vision"

export const metadata = {
  title: "Our Milestones | Enmark Power - Journey of Excellence",
  description:
    "Explore Enmark Power's journey from incorporation in 2023 to becoming a trusted name in power solutions. Discover our key milestones and achievements.",
}

export default function MilestonesPage() {
  return (
    <main className="min-h-screen">
      <Header />
      <MilestoneHero />
      <MilestoneTimeline />
      <CompanyJourney />
      <FutureVision />
      <Footer />
    </main>
  )
}
